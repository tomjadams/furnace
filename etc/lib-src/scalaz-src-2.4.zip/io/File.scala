// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 8011 $
// $LastChangedDate: 2008-02-13 13:18:38 +1000 (Wed, 13 Feb 2008) $


package scalaz.io;

import java.io.FileInputStream
import SStream._

/**
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 8011 $<br>
 *          $LastChangedDate: 2008-02-13 13:18:38 +1000 (Wed, 13 Feb 2008) $<br>
 *          $LastChangedBy: mtony $
 */
final class File(fl: java.io.File) { 
  lazy val file = fl
  
  lazy val lineSeparators = List('\r'.toByte, '\n'.toByte)
  
  def read[X](x: X, f: (X, Byte) => X) = { 
    val in = new FileInputStream(fl)
    import javas.InputStream.InputStreamByteIterator
  
    try {
      in.foldLeft(x)(f)
    } finally {
      in.close
    }
  }
  
  def each(f: Byte => Unit) = { 
    val in = new FileInputStream(fl)
    import javas.InputStream.InputStreamByteIterator
  
    try {
      in.foreach(f)
    } finally {
      in.close
    }
  }
  
  def readLines[X, Y](x: X, f: (X, Char) => X, y: Y, g: (Y, X) => Y) = { 
    val in = new FileInputStream(fl)
    import javas.InputStream.InputStreamByteIterator
    import IIterator._
    
    try {
      in.map(_.toChar).foldFoldLeft(lineSeparators.contains(_))(x, f, y, g)
    } finally {
      in.close
    }
  }
   
  def eachLine(f: List[Char] => Unit) =
    readLines(Nil, (b: List[Char], c) => b ::: (c :: Nil), (), (u: Unit, b: List[Char]) => f(b))  
  
  def read[X](f: Stream[Byte] => X) = {
    val in = new FileInputStream(fl)
    import javas.InputStream.InputStreamByteStream
  
    try {
      f(in)
    } finally {
      in.close
    }
  }
  
  def readLines[X](f: Stream[Stream[Byte]] => X) = 
    read(bs => f(bs.breaks(lineSeparators.contains(_))
        .filter(cs => !cs.isEmpty && !lineSeparators.contains(cs.head))))
}

object File {
  implicit def JavaFileFile(f: java.io.File) = new File(f)
  
  implicit def FileJavaFile(f: File) = f.file
  
  implicit def StringFile(s: String): File = new java.io.File(s)
  
  implicit def URIFile(u: java.net.URI): File = new java.io.File(u)
}
