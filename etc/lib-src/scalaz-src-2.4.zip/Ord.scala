// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 7688 $
// $LastChangedDate: 2008-01-25 12:21:26 +1000 (Fri, 25 Jan 2008) $


package scalaz

/**
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 7688 $<br>
 *          $LastChangedDate: 2008-01-25 12:21:26 +1000 (Fri, 25 Jan 2008) $<br>
 *          $LastChangedBy: mtony $
 */
abstract class Ord[A](implicit e: Equal[A]) {
  def compare(a1: A, a2: A): Ordering = if(<(a1, a2)) LT else if(>(a1, a2)) GT else EQ

  def <(a1: A, a2: A) = compare(a1, a2) == LT

  def >(a1: A, a2: A) = compare(a1, a2) == GT

  def <=(a1: A, a2: A) = compare(a1, a2) != GT

  def >=(a1: A, a2: A) = compare(a1, a2) != LT
}

object Ord {
  implicit def OrdBoolean: Ord[Boolean] = new Ord[Boolean] {
    override def compare(a1: Boolean, a2: Boolean): Ordering = if(a1 > a2) GT else if(a1 < a2) LT else EQ
  }

  implicit def OrdByte: Ord[Byte] = new Ord[Byte] {
    override def compare(a1: Byte, a2: Byte): Ordering = if(a1 > a2) GT else if(a1 < a2) LT else EQ
  }

  implicit def OrdChar: Ord[Char] = new Ord[Char] {
    override def compare(a1: Char, a2: Char): Ordering = if(a1 > a2) GT else if(a1 < a2) LT else EQ
  }

  implicit def OrdDouble: Ord[Double] = new Ord[Double] {
    override def compare(a1: Double, a2: Double): Ordering = if(a1 > a2) GT else if(a1 < a2) LT else EQ
  }

  implicit def OrdFloat: Ord[Float] = new Ord[Float] {
    override def compare(a1: Float, a2: Float): Ordering = if(a1 > a2) GT else if(a1 < a2) LT else EQ
  }

  implicit def OrdInt: Ord[Int] = new Ord[Int] {
    override def compare(a1: Int, a2: Int): Ordering = if(a1 > a2) GT else if(a1 < a2) LT else EQ
  }

  implicit def OrdLong: Ord[Long] = new Ord[Long] {
    override def compare(a1: Long, a2: Long): Ordering = if(a1 > a2) GT else if(a1 < a2) LT else EQ
  }

  implicit def OrdShort: Ord[Short] = new Ord[Short] {
    override def compare(a1: Short, a2: Short): Ordering = if(a1 > a2) GT else if(a1 < a2) LT else EQ
  }
}
