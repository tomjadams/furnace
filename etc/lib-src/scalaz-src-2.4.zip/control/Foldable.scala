// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 8635 $
// $LastChangedDate: 2008-03-20 11:05:20 +1000 (Thu, 20 Mar 2008) $


package scalaz.control

/**
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 8635 $<br>
 *          $LastChangedDate: 2008-03-20 11:05:20 +1000 (Thu, 20 Mar 2008) $<br>
 *          $LastChangedBy: mtony $
 */
trait Foldable[T[_]] {
  def foldRight[A, B](t: T[A], b: B, f: (A, => B) => B): B
  def foldLeft[A, B](t: T[B], a: A, f: (A, B) => A): A
}

import Maybe._

object Foldable { 
  def EmptyFoldable[X[_]]: Foldable[X] = new Foldable[X] {
    override def foldRight[A, B](t: X[A], b: B, f: (A, => B) => B): B = b
      
    override def foldLeft[A, B](t: X[B], a: A, f: (A, B) => A) = a
  }
  
  implicit lazy val OptionFoldable: Foldable[Option] = new Foldable[Option] {
    override def foldRight[A, B](t: Option[A], b: B, f: (A, => B) => B): B = t match {
      case None => b
      case Some(a) => f(a, b)
    }
      
    override def foldLeft[A, B](t: Option[B], a: A, f: (A, B) => A) = t match {
      case None => a
      case Some(b) => f(a, b)
    }
  }
  
  implicit lazy val ListFoldable: Foldable[List] = new Foldable[List] {
    override def foldRight[A, B](t: List[A], b: B, f: (A, => B) => B): B = t match {
      case Nil => b
      case x :: xs => f(x, foldRight(xs, b, f))   
    }
    override def foldLeft[A, B](t: List[B], a: A, f: (A, B) => A) = t.foldLeft(a)(f)
  }
 
  implicit lazy val StreamFoldable: Foldable[Stream] = new Foldable[Stream] {
    override def foldRight[A, B](t: Stream[A], b: B, f: (A, => B) => B): B =
      if(t.isEmpty) b else f(t.head, foldRight(t.tail, b, f))
    override def foldLeft[A, B](t: Stream[B], a: A, f: (A, B) => A) = t.foldLeft(a)(f)
  }
  
  implicit lazy val ArrayFoldable: Foldable[Array] = new Foldable[Array] {
    override def foldRight[A, B](t: Array[A], b: B, f: (A, => B) => B): B = t.foldRight(b)((a, b) => f(a, b))
    override def foldLeft[A, B](t: Array[B], a: A, f: (A, B) => A) = t.foldLeft(a)(f)
  }

  implicit lazy val IterableFoldable: Foldable[Iterable] = new Foldable[Iterable] {
    override def foldRight[A, B](t: Iterable[A], b: B, f: (A, => B) => B): B = t.foldRight(b)((a, b) => f(a, b))
    override def foldLeft[A, B](t: Iterable[B], a: A, f: (A, B) => A) = t.foldLeft(a)(f)
  }

  implicit lazy val IteratorFoldable: Foldable[Iterator] = new Foldable[Iterator] {
    override def foldRight[A, B](t: Iterator[A], b: B, f: (A, => B) => B): B =
      if(t.hasNext) b else {
        val a = t.next
        f(a, foldRight(t, b, f))
      }
    override def foldLeft[A, B](t: Iterator[B], a: A, f: (A, B) => A) = t.foldLeft(a)(f)
  }

  import MonadPlus.plusUnit
  
  final class F[F[_], A](fa: => F[A])(implicit fd: Foldable[F]) {
    def *:[B](b: B, f: (B, A) => B) = fd.foldLeft(fa, b, f)     
    
    def :*[B](b: B, f: (A, => B) => B) = fd.foldRight[A, B](fa, b, f)
    
    def **:(f: (A, A) => A) = fd.foldLeft[Option[A], A](fa, None, (a, b) => Some(a.option(b, f(b, _)))).err("empty")
    
    def :*(f: (A, A) => A) = fd.foldRight[A, Option[A]](fa, None, (a, b) => Some(b.option(a, f(a, _)))).err("empty")
    
    def ~>[M](f: A => M)(implicit m: Monoid[M]) =
      fd.foldRight[A, M](fa, m.empty, (a, b) => m.append(f(a), b))
      
    def +>[M](f: A => M)(implicit m: Monoid[M]) =
      fd.foldLeft[M, A](fa, m.empty, (a, b) => m.append(f(b), a))
    
    def appendRight[B, F2[_]](b: B, f: (A, => B) => B, fa2: F2[A])(implicit fd2: Foldable[F2]) = 
      fd.foldRight[A, B](fa, fd2.foldRight[A, B](fa2, b, f), f)
      
    def ~|[B](b: B, f: (A, => B) => B, fa2: F[A]) =
      appendRight[B, F](b, f, fa2)
    
    def appendLeft[B, F2[_]](b: B, f: (B, A) => B, fa2: F2[A])(implicit fd2: Foldable[F2]) = 
      fd2.foldLeft[B, A](fa2, fd.foldLeft[B, A](fa, b, f), f)
      
    def +|[B](b: B, f: (B, A) => B, fa2: F[A]) =
      appendLeft[B, F](b, f, fa2)
    
    def !(n: Int) = unary_-(n)
    
    def each(f: A => Unit) =
      fd.foldLeft[Unit, A](fa, (), (u, a) => f(a))
      
    def intersperse[M[_]](sep: M[A])(implicit m: MonadPlus[M]): M[A] =
      fd.foldRight[A, (M[A], Boolean)](fa, (m.zero, true), (a, b) =>
        (plusUnit[A, M](a, m.plus(if(b._2) m.zero else sep, b._1)), false))._1
      
    def any(p: A => Boolean) = 
      fd.foldRight[A, Boolean](fa, false, p(_) || _)
      
    def all(p: A => Boolean) = 
      fd.foldRight[A, Boolean](fa, true, p(_) && _)     
      
    lazy val ! = any(a => true)
        
    def ~[M[_]](p: A => Boolean)(implicit m: MonadPlus[M]) =
      fd.foldRight[A, M[A]](fa, m.zero, (a, as) => if(p(a)) plusUnit[A, M](a, as) else as)
      
    def <~[M[_]](p: A => Boolean)(implicit m: MonadPlus[M]) =
      fd.foldRight[A, M[A]](fa, m.zero, (a, as) => if(p(a)) plusUnit[A, M](a, as) else m.zero)
        
    def max(implicit ord: Ord[A]) =
      **:((x: A, y: A) => if(ord.compare(x, y) == GT) x else y)
        
    def maximum(implicit ord: (A, A) => Ordering) =
      **:((x: A, y: A) => if(ord(x, y) == GT) x else y)
        
    def min(implicit ord: Ord[A]) =
      **:((x: A, y: A) => if(ord.compare(x, y) == LT) x else y)
        
    def minimum(implicit ord: (A, A) => Ordering) =
      **:((x: A, y: A) => if(ord(x, y) == LT) x else y)
 
    lazy val unary_~ = fd.foldLeft[Int, A](fa, 0, (a, b) => a + 1)
    
    def unary_+(implicit m: Monoid[A]) = ~>(identity[A])
    
    lazy val unary_- = fd.foldRight[A, Stream[A]](fa, Stream.empty, Stream.cons(_, _))
    
    lazy val unary_! = fd.foldLeft[List[A], A](fa, Nil, _ ::: List(_))
    
    def ifEmpty[X](t: => X, f: => X) = if(this !) f else t
    
    def ifElseEmpty[X](t: => X, f: => X) = if(this !) t else f
    
    def ?[X](t: => X, f: => X) = ifEmpty(t, f)
    
    def ifEmptyZeroElseHead[M[_]](implicit m: MonadZero[M]) = if((-this).isEmpty) m.zero else m.unit((-this).head)
    
    def ifEmptyHeadElseZero[M[_]](implicit m: MonadZero[M]) = if((-this).isEmpty) m.unit((-this).head) else m.zero
    
    def emptyElse[M](notEmpty: => M)(implicit m: Monoid[M]): M =
      ifEmpty(m.empty, notEmpty)
      
    def elseEmpty[M](empty: => M)(implicit m: Monoid[M]) =
      ifEmpty(empty, m.empty)
  }
  
  implicit def OptionF[A](as: => Option[A])(implicit m: Foldable[Option]): F[Option, A] = new F[Option, A](as)(m)
  
  implicit def ListF[A](as: => List[A])(implicit m: Foldable[List]): F[List, A] = new F[List, A](as)(m)
  
  implicit def StreamF[A](as: => Stream[A])(implicit m: Foldable[Stream]): F[Stream, A] = new F[Stream, A](as)(m)
  
  implicit def ArrayF[A](as: => Array[A])(implicit m: Foldable[Array]): F[Array, A] = new F[Array, A](as)(m)
  
  implicit def IterableF[A](as: => Iterable[A])(implicit m: Foldable[Iterable]): F[Iterable, A] = new F[Iterable, A](as)(m)

  implicit def IteratorF[A](as: => Iterator[A])(implicit m: Foldable[Iterator]): F[Iterator, A] = new F[Iterator, A](as)(m)

  def asMap[T[_], SM[_], K, V](e: Map[K, SM[V]], kvs: T[(K, V)])
    (implicit f: Foldable[T], s: Semigroup[SM[V]], md: Monad[SM]): Map[K, SM[V]] =
    f.foldLeft[Map[K, SM[V]], (K, V)](kvs, e, (m, kv) => m + ((kv._1, m.get(kv._1) match {
      case None => md.unit(kv._2)
      case Some(vv) => s.append(md.unit(kv._2), vv)
    })))    
}

