// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 8407 $
// $LastChangedDate: 2008-03-13 14:27:32 +1000 (Thu, 13 Mar 2008) $


package scalaz;

import control.Monad._

/**
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 8407 $<br>
 *          $LastChangedDate: 2008-03-13 14:27:32 +1000 (Thu, 13 Mar 2008) $<br>
 *          $LastChangedBy: mtony $
 */
final class Maybe[A](o: Option[A]) {
  def option = o  
  
  def option[X](none: => X, some: => A => X) = o match {
    case None => none
    case Some(a) => some(a)
  }
  
  def all(f: A => Boolean) = o match {
    case None => true
    case Some(a) => f(a)
  }
  
  def any(f: A => Boolean) = o match {
    case None => false
    case Some(a) => f(a)
  }

  def ?[X](none: => X, some: => X) = o match {
    case None => none
    case Some(_) => some
  }
  
  def toEither[X](left: => X): Either[X, A] = o match {
    case None => Left(left)
    case Some(a) => Right(a)
  }
  
  def toEitherLeft[X](right: => X) = o match {
    case None => Right(right)
    case Some(b) => Left(b)
  }
    
  def ifNone(n: => Unit) = o match {
    case None => n
    case Some(b) => {}
  }  
  
  def err(message: => String) = o.getOrElse(error(message))
  
  def |(a: => A) = o getOrElse a
  
  lazy val toNull = o match { 
    case None => null.asInstanceOf[A]
    case Some(t) => t 
  }
}

object Maybe {
  implicit def MaybeOption[A](m: Maybe[A]) = m.option
  
  implicit def OptionMaybe[A](o: Option[A]) = new Maybe(o)   
}
