// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 7688 $
// $LastChangedDate: 2008-01-25 12:21:26 +1000 (Fri, 25 Jan 2008) $


package scalaz.lazytuple;

/**
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 7688 $<br>
 *          $LastChangedDate: 2008-01-25 12:21:26 +1000 (Fri, 25 Jan 2008) $<br>
 *          $LastChangedBy: mtony $
 */
final case class LT2[+A, +B](a: () => A, b: () => B) {

  def this(a: A, b: B) = 
    this(() => a, () => b)
    
  lazy val _1 = a()
  lazy val _2 = b()
  
  def fst[X](f: A => X) = LT2(() => f(a()), b)
  
  def snd[X](f: B => X) = LT2(a, () => f(b()))
  
  def toTuple = (a(), b())
}

object _LT2 {  
  def unapply[A, B](t: LT2[A, B]): Option[(A, B)] = Some(t._1, t._2)

  implicit def toTuple[A, B](t: => LT2[A, B]) = (t._1, t._2)
}
