// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 8347 $
// $LastChangedDate: 2008-03-10 10:42:29 +1000 (Mon, 10 Mar 2008) $


package scalaz

/**
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 8347 $<br>
 *          $LastChangedDate: 2008-03-10 10:42:29 +1000 (Mon, 10 Mar 2008) $<br>
 *          $LastChangedBy: mtony $
 */
sealed trait Bool {
  val isTrue: Boolean
    
  def /\(q: => Bool) = isTrue && q.isTrue // conjunction
  def \/(q: => Bool) = isTrue || q.isTrue // disjunction  
  def >-<(q: Bool) = isTrue != q.isTrue // exclusive disjunction (!=)  
  def <=>(q: Bool) = isTrue == q.isTrue // biconditional (==)  
  def ~/\(q: => Bool) = !isTrue || !q.isTrue // negation of conjunction
  def ~\/(q: => Bool) = !isTrue && !q.isTrue // negation of disjunction
  def ==>(q: => Bool) = !isTrue || q.isTrue // conditional
  def <==(q: => Bool) = isTrue || !q.isTrue // inverse conditional
  def ~==>(q: => Bool) = isTrue && !q.isTrue // negation of conditional  
  def ~<==(q: => Bool) = !isTrue && q.isTrue // negation of inverse conditional
  
  def iif[X](t: => X, f: => X) = if(isTrue) t else f
  def iif(t: => Unit) = if(isTrue) t
  def unless(f: => Unit) = if(!isTrue) f
  
  def ?[X](t: => X, f: => X) = iif(t, f)
  def ?=(t: => Unit) = iif(t)
  def ~?(f: => Unit) = unless(f)  
  
  def not = !isTrue
  
  def toOption[A](a: => A) = if(isTrue) Some(a) else None
  def +>[A](a: => A) = toOption(a)
  def toEither[A, B](a: => A, b: => B) = if(isTrue) Right(b) else Left(a)
  def ++>[A, B](a: => A, b: => B) = toEither(a, b)
}
private final case class Bool_(b: Boolean) extends Bool {
  override val isTrue = b
}

object Bool {
  implicit def BooleanBool(b: Boolean): Bool = Bool_(b)

  implicit def BoolBoolean(b: Bool) = b.isTrue
  
  def unapply(b: Bool): Option[Boolean] = Some(b.isTrue)
}
