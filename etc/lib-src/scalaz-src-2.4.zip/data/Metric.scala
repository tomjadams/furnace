// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 7771 $
// $LastChangedDate: 2008-01-31 18:31:12 +1000 (Thu, 31 Jan 2008) $


package scalaz.data;

// distance(x, y) >= 0
// distance(x, y) <-> x == y
// distance(x, y) == distance(y, x)
// distance(x, z) <= distance(x, y) + distance(y, z)

/**
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 7771 $<br>
 *          $LastChangedDate: 2008-01-31 18:31:12 +1000 (Thu, 31 Jan 2008) $<br>
 *          $LastChangedBy: mtony $
 */
trait Metric[A] {
	def distance(a1: A, a2: A): Int
}

import memo.Memo
import memo.SizedMemo.arraySizedMemo

object Metric {
  implicit def IntMetric = new Metric[Int] {
    override def distance(a1: Int, a2: Int) = Math.abs(a1 - a2)
  }
  
  implicit def CharMetric = new Metric[Char] {
    override def distance(a1: Char, a2: Char) = Math.abs(a1 - a2)
  }
  
  implicit def ArrayMetric[A] = new Metric[Array[A]] {
    override def distance(x: Array[A], y: Array[A]) = {
      val matrix: Int => Int => Int = {
        val im = arraySizedMemo
        val m = im[Memo[Int, Int]](x.length + 1)

        def get(i: Int)(j: Int): Int = if(i == 0) j else if(j == 0) i else {
          lazy val t = x(i - 1)
          lazy val u = y(j - 1)
          lazy val e = t == u

          def f = (n: Int) => im[Int](y.length + 1)
          def a = m(f)(i - 1)(get(i - 1))(j) + 1
          def b = m(f)(i - 1)(get(i - 1))(j - 1) + (if(e) 0 else 1)
          def c = m(f)(i)(get(i))(j - 1) + 1

          if(a < b) a else if(b <= c) b else c
        }
        get
      }
      
      matrix(x.length)(y.length)
    }
  }
  
  implicit def StringMetric = new Metric[String] {
    override def distance(x: String, y: String) = {
      val matrix: Int => Int => Int = {
        val im = arraySizedMemo
        val m = im[Memo[Int, Int]](x.length + 1)

        def get(i: Int)(j: Int): Int = if(i == 0) j else if(j == 0) i else {
          lazy val t = x(i - 1)
          lazy val u = y(j - 1)
          lazy val e = t == u

          def f = (n: Int) => im[Int](y.length + 1)
          def a = m(f)(i - 1)(get(i - 1))(j) + 1
          def b = m(f)(i - 1)(get(i - 1))(j - 1) + (if(e) 0 else 1)
          def c = m(f)(i)(get(i))(j - 1) + 1

          if(a < b) a else if(b <= c) b else c
        }
        get
      }
      
      matrix(x.length)(y.length)
    }
  }
}
