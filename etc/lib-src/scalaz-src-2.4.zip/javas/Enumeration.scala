// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 8349 $
// $LastChangedDate: 2008-03-10 11:18:46 +1000 (Mon, 10 Mar 2008) $


package scalaz.javas;

/**
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 8349 $<br>
 *          $LastChangedDate: 2008-03-10 11:18:46 +1000 (Mon, 10 Mar 2008) $<br>
 *          $LastChangedBy: mtony $
 */
object Enumeration {
  implicit def EnumerationIterator[A](e: java.util.Enumeration[A]) = new Iterator[A] {
    override def hasNext = e.hasMoreElements
    override def next = e.nextElement
  }
}
