// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 7688 $
// $LastChangedDate: 2008-01-25 12:21:26 +1000 (Fri, 25 Jan 2008) $


package scalaz;

import function.Function.const

/**
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 7688 $<br>
 *          $LastChangedDate: 2008-01-25 12:21:26 +1000 (Fri, 25 Jan 2008) $<br>
 *          $LastChangedBy: mtony $
 */
object Prelude {
  /**
   * <pre>
   * def a = expr
   * effect(a)
   * a
   * </pre>
   * is equivalent to:
   * <pre>
   * using(expr, effect(_))
   * </pre>
   */
  def using[A](a: => A, f: (=> A) => Unit) = {
    f(a)
    a
  }

 /**
  * <pre>
  * val a = expr
  * effect(a)
  * a
  * </pre>
  * is equivalent to:
  * <pre>
  * usings(expr, effect(_))
  * </pre>
  */
  def usings[A](a: A, f: A => Unit) = {
    f(a)
    a
  }

  def ifNull[A, X](a: A, n: => X, nn: A => X) = if(a == null) n else nn(a)
}
