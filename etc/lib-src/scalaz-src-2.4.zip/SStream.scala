// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision$
// $LastChangedDate$


package scalaz;

import control.Foldable.StreamF
import Stream.{cons, empty}

/**
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 7681 $<br>
 *          $LastChangedDate: 2008-01-25 11:03:00 +1000 (Fri, 25 Jan 2008) $<br>
 *          $LastChangedBy: mtony $
 */
final class SStream[A](as: => Stream[A]) {
	def stream = as
  
  def breaks(f: A => Boolean) =
    as.:*[Stream[Stream[A]]](cons(empty, empty), (a, as) => {
      lazy val x = f(a) == (!as.head.isEmpty && f(as.head.head))
      cons(cons(a, if(x) as.head else empty), if(as.isEmpty) empty else if(x) as.tail else as)       
    }) 
}

object SStream {
  implicit def SStreamStream[A](as: SStream[A]) = as.stream
  
  implicit def StreamSStream[A](as: Stream[A]) = new SStream(as) 
}
