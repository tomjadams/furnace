// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 7688 $
// $LastChangedDate: 2008-01-25 12:21:26 +1000 (Fri, 25 Jan 2008) $


package scalaz.lazytuple;

/**
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 7688 $<br>
 *          $LastChangedDate: 2008-01-25 12:21:26 +1000 (Fri, 25 Jan 2008) $<br>
 *          $LastChangedBy: mtony $
 */
final case class LT4[+A, +B, +C, +D](a: () => A, b: () => B, c: () => C, d: () => D) {
  
  def this(a: A, b: B, c: C, d: D) = 
    this(() => a, () => b, () => c, () => d)

  lazy val _1 = a()
  lazy val _2 = b()
  lazy val _3 = c()
  lazy val _4 = d()
}

object _LT4 {  
  def unapply[A, B, C, D](t: LT4[A, B, C, D]): Option[(A, B, C, D)] = 
    Some(t._1, t._2, t._3, t._4)

  implicit def toTuple[A, B, C, D](t: => LT4[A, B, C, D]) = (t._1, t._2, t._3, t._4)
}
