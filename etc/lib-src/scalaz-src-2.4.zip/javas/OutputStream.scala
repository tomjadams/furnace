// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 8162 $
// $LastChangedDate: 2008-02-21 11:29:25 +1000 (Thu, 21 Feb 2008) $


package scalaz.javas;

import Closeable.close

/**
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 8162 $<br>
 *          $LastChangedDate: 2008-02-21 11:29:25 +1000 (Thu, 21 Feb 2008) $<br>
 *          $LastChangedBy: mtony $
 */
object OutputStream {
  def write(out: java.io.OutputStream, bytes: Stream[Byte]) =
    close(out, bytes.foreach(out.write(_)))
    
  def write(out: java.io.OutputStream, bytes: Iterator[Byte]) =
    close(out, bytes.foreach(out.write(_)))
}
