// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 8078 $
// $LastChangedDate: 2008-02-14 17:03:01 +1000 (Thu, 14 Feb 2008) $


package scalaz.control

/**
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 8078 $<br>
 *          $LastChangedDate: 2008-02-14 17:03:01 +1000 (Thu, 14 Feb 2008) $<br>
 *          $LastChangedBy: mtony $
 */
abstract class MonadZero[M[_]](implicit m: Monad[M]) {
  def zero[A]: M[A]
  def *[A] = zero[A]
  def map[A, B](ft: => M[A], f: => A => B) = m.map(ft, f)
  def bind[A, B](ma: => M[A], f: A => M[B]) = m.bind(ma, f)
  def unit[A](a: => A) = m.unit(a)
  lazy val monad = m
}

object MonadZero {
  implicit lazy val OptionMonadZero: MonadZero[Option] = new MonadZero[Option] {
    override def zero[A] = None
  }     
  
  implicit lazy val ListMonadZero: MonadZero[List] = new MonadZero[List] {
    override def zero[A] = Nil
  }

  implicit lazy val StreamMonadZero: MonadZero[Stream] = new MonadZero[Stream] {
    override def zero[A] = Stream.empty
  }
  
  implicit lazy val ArrayMonadZero: MonadZero[Array] = new MonadZero[Array] {
    override def zero[A] = new Array(0)
  }  
}
