// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 7688 $
// $LastChangedDate: 2008-01-25 12:21:26 +1000 (Fri, 25 Jan 2008) $


package scalaz.function

/**
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 7688 $<br>
 *          $LastChangedDate: 2008-01-25 12:21:26 +1000 (Fri, 25 Jan 2008) $<br>
 *          $LastChangedBy: mtony $
 */
final class Function2[-T1, -T2, +R](f: scala.Function2[T1, T2, R]) {
  def function = f

  def apply(v1: T1, v2: T2) = f(v1, v2)

  override def toString = f.toString

  def flip = new Function2[T2, T1, R]((b, a) => f(a, b))
  
  def flipc = (b: T2) => (a: T1) => f(a, b) 
  
  def curry = (a: T1) => (b: T2) => f(a, b)
}

object Function2 {
  def apply[T1, T2, R](f: scala.Function2[T1, T2, R]) = new Function2(f)
  
  implicit def ScalaFunction2_Function2[T1, T2, R](f: scala.Function2[T1, T2, R]) = new Function2(f)
  
  implicit def Function2_ScalaFunction2[T1, T2, R](f: Function2[T1, T2, R]) = f.function
}
