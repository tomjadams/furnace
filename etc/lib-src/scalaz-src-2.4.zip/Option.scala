// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 8227 $
// $LastChangedDate: 2008-02-25 13:26:31 +1000 (Mon, 25 Feb 2008) $


package scalaz;

import control.{Foldable, MonadPlus}
import control.MonadPlus.plusUnit

/**
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 8227 $<br>
 *          $LastChangedDate: 2008-02-25 13:26:31 +1000 (Mon, 25 Feb 2008) $<br>
 *          $LastChangedBy: mtony $
 */
object Option {
  def some[A](a: A): Option[A] = Some(a)
  
  def none[A]: Option[A] = None
  
  def onull[A](a: A) = if(a == null) None else Some(a)
 
  def oint(n: Int) = if(n < 0) None else Some(n)
  
  def join[A](o: Option[Option[A]]) = o.flatMap(x => x)

  def somesX[A, FD[_], MP[_]](os: FD[Option[A]])(implicit fd: Foldable[FD], mp: MonadPlus[MP]): MP[A] = 
    fd.foldRight[Option[A], MP[A]](os, mp.zero, (a, b) => a match {
      case Some(a) => plusUnit[A, MP](a, b)
      case None => b
    })
  
  def somes[A](os: Iterable[Option[A]]) = somesX[A, Iterable, List](os)
  
  def threw[A](a: => A): Option[A] = 
    try {
      Some(a)
    } catch {
      case _ => None
    }

  def iif[A](f: A => Boolean)(a: => A) = if(f(a)) Some(a) else None

  def iif[A](c: Boolean)(a: => A) = if(c) Some(a) else None
}

