// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 8009 $
// $LastChangedDate: 2008-02-13 12:53:45 +1000 (Wed, 13 Feb 2008) $


package scalaz

/**
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 8009 $<br>
 *          $LastChangedDate: 2008-02-13 12:53:45 +1000 (Wed, 13 Feb 2008) $<br>
 *          $LastChangedBy: mtony $
 */
final class IIterator[A](i: Iterator[A]) {
  lazy val iterator = i
   
  def foldFoldLeft[X, Y](p: A => Boolean)(x: X, f: (X, A) => X, y: Y, g: (Y, X) => Y): Y = {
    var t = x
    var u = y
     
    while(i.hasNext) {
      val c = i.next
        
      if(p(c)) {
        u = g(u, t)
        t = x
      } else
        t = f(t, c)       
    }
        
    u
  }
}
 
object IIterator {
  implicit def IteratorIIterator[A](i: Iterator[A]) = new IIterator(i)
  
  implicit def IIteratorIterator[A](i: IIterator[A]) = i.iterator
}
