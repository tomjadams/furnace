// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 8278 $
// $LastChangedDate: 2008-02-29 09:50:51 +1000 (Fri, 29 Feb 2008) $


package scalaz.validation;

import control.{Semigroup, Monad, Foldable, MonadPlus}
import control.Functor._

/**
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 8278 $<br>
 *          $LastChangedDate: 2008-02-29 09:50:51 +1000 (Fri, 29 Feb 2008) $<br>
 *          $LastChangedBy: mtony $
 */
sealed abstract class Validation[SM[_], ERR, A](implicit s: Semigroup[SM[ERR]]) {
  def >*>[B, C](v: Validation[SM, ERR, B], f: (A, B) => C): Validation[SM, ERR, C] = 
    (this, v) match {
      case (V(Left(es1)), V(Left(es2))) => V[SM, ERR, C](Left(s.append(es1, es2)))
      case (V(Left(es1)), V(Right(_))) => V[SM, ERR, C](Left(es1))
      case (V(Right(_)), V(Left(es2))) => V[SM, ERR, C](Left(es2))
      case (V(Right(a)), V(Right(b))) => V[SM, ERR, C](Right(f(a, b)))
    }   
  
  def *>(v: Validation[SM, ERR, A])(implicit f: (A, A) => A): Validation[SM, ERR, A] =
    >*>[A, A](v, f)
    
  def ~>[B](v: Validation[SM, ERR, B]) = >*>[B, (A, B)](v, (a, b) => (a, b))
  
  lazy val either = Validation.veither[SM, ERR, A](this)
  
  lazy val isFail = this match {
    case V(Left(_)) => true
    case V(Right(_)) => false
  }
  
  lazy val isSuccess = !isFail
}
private final case class V[SM[_], ERR, A](e: Either[SM[ERR], A])(implicit s: Semigroup[SM[ERR]]) extends Validation[SM, ERR, A]

import Maybe._

object Validation {
  object Fail {
    def unapply[SM[_], ERR, A](v: Validation[SM, ERR, A]): Option[SM[ERR]] = v match {
      case V(Left(errs)) => Some(errs)
      case V(Right(_)) => None
    }
  }
  
  object Success {
    def unapply[SM[_], ERR, A](v: Validation[SM, ERR, A]): Option[A] = v match {
      case V(Right(a)) => Some(a)
      case V(Left(_)) => None
    }
  }
  
  implicit def veither[SM[_], ERR, A](v: Validation[SM, ERR, A]): Either[SM[ERR], A] = v match {
    case V(e) => e
  }
  
  implicit def validations[SM[_], ERR, A](e: Either[SM[ERR], A])(implicit s: Semigroup[SM[ERR]]): Validation[SM, ERR, A] = 
    V[SM, ERR, A](e)
    
  implicit def validationso[SM[_], ERR, A](o: Option[SM[ERR]], a: => A)(implicit s: Semigroup[SM[ERR]]): Validation[SM, ERR, A] =
    V[SM, ERR, A](~o.toEither(a))
    
  implicit def validationsoa[SM[_], ERR, A](o: Option[A], e: => SM[ERR])(implicit s: Semigroup[SM[ERR]]): Validation[SM, ERR, A] =
    V[SM, ERR, A](o.toEither(e))
  
  implicit def validation[SM[_], ERR, A](e: Either[ERR, A])(implicit s: Semigroup[SM[ERR]], m: Monad[SM]): Validation[SM, ERR, A] = 
    V[SM, ERR, A](e <| (m.unit(_)))
      
  implicit def validationo[SM[_], ERR, A](o: Option[ERR], a: => A)(implicit s: Semigroup[SM[ERR]], m: Monad[SM]): Validation[SM, ERR, A] =
    V[SM, ERR, A](~(o |> (m.unit(_))).toEither(a))
      
  implicit def validationoa[SM[_], ERR, A](o: Option[A], e: => ERR)(implicit s: Semigroup[SM[ERR]], m: Monad[SM]): Validation[SM, ERR, A] =
    V[SM, ERR, A](o.toEither(e) <| (m.unit(_)))
    
  implicit def validatione[SM[_], ERR, A](e: ERR)(implicit s: Semigroup[SM[ERR]], m: Monad[SM]): Validation[SM, ERR, A] = 
    V[SM, ERR, A](Left(e) <| (m.unit(_)))
    
  implicit def validationa[SM[_], ERR, A](a: A)(implicit s: Semigroup[SM[ERR]], m: Monad[SM]): Validation[SM, ERR, A] = 
    V[SM, ERR, A](Right(a) <| (m.unit(_)))
    
  implicit def validationf[SM[_], ERR, A](f: A => Option[ERR], a: A)(implicit s: Semigroup[SM[ERR]], m: Monad[SM]): Validation[SM, ERR, A] = 
    validationo[SM, ERR, A](f(a), a)
     

  def sum[FD[_], MP[_], SM[_], ERR, A](vs: FD[Validation[SM, ERR, A]])(implicit
      s: Semigroup[SM[ERR]],
      m: Monad[SM],
      fd: Foldable[FD],
      mp: MonadPlus[MP]): Validation[SM, ERR, MP[A]] =
    fd.foldLeft[Validation[SM, ERR, MP[A]], Validation[SM, ERR, A]](vs, 
        validationa[SM, ERR, MP[A]](mp.zero), (a, b) => 
          a.*>(validations[SM, ERR, MP[A]](veither[SM, ERR, A](b) |> (mp.unit(_))))(mp.plus(_: MP[A], _: MP[A])))     
}
