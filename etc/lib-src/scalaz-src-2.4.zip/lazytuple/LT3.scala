// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 7688 $
// $LastChangedDate: 2008-01-25 12:21:26 +1000 (Fri, 25 Jan 2008) $


package scalaz.lazytuple;

/**
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 7688 $<br>
 *          $LastChangedDate: 2008-01-25 12:21:26 +1000 (Fri, 25 Jan 2008) $<br>
 *          $LastChangedBy: mtony $
 */
final case class LT3[+A, +B, +C](a: () => A, b: () => B, c: () => C) {

  def this(a: A, b: B, c: C) = 
    this(() => a, () => b, () => c)
    
  lazy val _1 = a()
  lazy val _2 = b()
  lazy val _3 = c()
}

object _LT3 {  
  def unapply[A, B, C](t: LT3[A, B, C]): Option[(A, B, C)] = Some(t._1, t._2, t._3)

  implicit def toTuple[A, B, C](t: => LT3[A, B, C]) = (t._1, t._2, t._3)
}
