// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 8117 $
// $LastChangedDate: 2008-02-18 12:25:17 +1000 (Mon, 18 Feb 2008) $


package scalaz.javas;

/**
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 8117 $<br>
 *          $LastChangedDate: 2008-02-18 12:25:17 +1000 (Mon, 18 Feb 2008) $<br>
 *          $LastChangedBy: build $
 */
object List {
  implicit def JavaList_ScalaList[A](xs: java.util.List[A]): scala.List[A] = xs match {
    case NonEmpty(h, t) => h :: t
    case Empty(_) => Nil
  } 
  
  implicit def ScalaList_JavaList[A](xs: scala.List[A]): java.util.List[A] = {
    val l = new java.util.LinkedList[A]
    xs.foreach(x => l.add(x))
    l
  }
  
  object NonEmpty {
    def tail[A](xs: java.util.List[A]) = 
      if(xs.isEmpty) error("tail: empty list") 
      else xs.subList(1, xs.size) 
      
    def unapply[A](xs: java.util.List[A]): Option[(A, java.util.List[A])] =
      if(xs.isEmpty) None
      else Some((xs.get(0), tail(xs)))
  }
  
  object Empty {    
    def unapply[A](xs: java.util.List[A]): Option[Unit] = 
      if(xs.isEmpty) Some(())
      else None
  }    
}
