// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 8170 $
// $LastChangedDate: 2008-02-21 14:32:31 +1000 (Thu, 21 Feb 2008) $


package scalaz.control

/**
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 8170 $<br>
 *          $LastChangedDate: 2008-02-21 14:32:31 +1000 (Thu, 21 Feb 2008) $<br>
 *          $LastChangedBy: mtony $
 */
trait Functor[F[_]] {
  def map[A, B](ft: => F[A], f: A => B): F[B]
  def each[A](ft: => F[A], f: A => Unit): Unit
}

object Functor {
  implicit lazy val OptionFunctor = new Functor[Option] {
    override def map[A, B](ft: => Option[A], f: A => B) = ft map f
    override def each[A](ft: => Option[A], f: A => Unit) = ft foreach f
  }

  implicit lazy val ListFunctor = new Functor[List] {
    override def map[A, B](ft: => List[A], f: A => B) = ft map f
    override def each[A](ft: => List[A], f: A => Unit) = ft foreach f
  }

  implicit lazy val StreamFunctor = new Functor[Stream] {
    override def map[A, B](ft: => Stream[A], f: A => B) = ft map f
    override def each[A](ft: => Stream[A], f: A => Unit) = ft foreach f
  }

  implicit lazy val ArrayFunctor = new Functor[Array] {
    override def map[A, B](ft: => Array[A], f: A => B) = ft map f
    override def each[A](ft: => Array[A], f: A => Unit) = ft foreach f
  }
  
  final class Ftr[F[_], A](fa: => F[A])(implicit ftr: Functor[F]) { 
    def map[B](f: A => B) = ftr map(fa, f)
    def |>[B](f: A => B) = map(f)
    def each(f: A => Unit) = ftr each(fa, f)
    def !>(f: A => Unit) = each(f)
    def each2[B](fb: F[B], f: (A, B) => Unit) = 
      each(a => ftr.each[B](fb, f(a, _)))
    def !!>[B](fb: F[B], f: (A, B) => Unit) = each2(fb, f)
    def each3[B, C](fb: F[B], fc: F[C], f: (A, B, C) => Unit) =
      each(a => ftr.each[B](fb, b => ftr.each[C](fc, f(a, b, _))))
    def !!!>[B, C](fb: F[B], fc: F[C], f: (A, B, C) => Unit) = each3(fb, fc, f)
    def each4[B, C, D](fb: F[B], fc: F[C], fd: F[D], f: (A, B, C, D) => Unit) =
      each(a => ftr.each[B](fb, b => ftr.each[C](fc, c => ftr.each[D](fd, f(a, b, c, _)))))
    def !!!!>[B, C, D](fb: F[B], fc: F[C], fd: F[D], f: (A, B, C, D) => Unit) = each4(fb, fc, fd, f)    
    def each5[B, C, D, E](fb: F[B], fc: F[C], fd: F[D], fe: F[E], f: (A, B, C, D, E) => Unit) =
      each(a => ftr.each[B](fb, b => ftr.each[C](fc, c => ftr.each[D](fd, d => ftr.each[E](fe, f(a, b, c, d, _))))))
    def !!!!!>[B, C, D, E](fb: F[B], fc: F[C], fd: F[D], fe: F[E], f: (A, B, C, D, E) => Unit) = each5(fb, fc, fd, fe, f)        
  }
  
  implicit def OptionFtr[A](as: => Option[A])(implicit f: Functor[Option]) =
    new Ftr[Option, A](as)(f)
    
  implicit def ListFtr[A](as: => List[A])(implicit f: Functor[List]) =
    new Ftr[List, A](as)(f)     
  
  implicit def StreamFtr[A](as: => Stream[A])(implicit f: Functor[Stream]) =
    new Ftr[Stream, A](as)(f)
      
  implicit def ArrayFtr[A](as: => Array[A])(implicit f: Functor[Array]) =
    new Ftr[Array, A](as)(f)
}
