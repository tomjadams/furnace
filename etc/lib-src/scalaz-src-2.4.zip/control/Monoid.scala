// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 8385 $
// $LastChangedDate: 2008-03-12 12:53:09 +1000 (Wed, 12 Mar 2008) $


package scalaz.control

/**
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 8385 $<br>
 *          $LastChangedDate: 2008-03-12 12:53:09 +1000 (Wed, 12 Mar 2008) $<br>
 *          $LastChangedBy: mtony $
 */
abstract class Monoid[A](implicit s: Semigroup[A]) {
  val empty: A
  lazy val * = empty
  def append(a1: => A, a2: => A): A = s.append(a1, a2)
  def concat[T[_]](as: => T[A])(implicit f: Foldable[T]): A = f.foldRight[A, A](as, empty, (a, b) => s.append(a, b))
  lazy val semigroup = s
}

object Monoid {
  implicit lazy val UnitMonoid: Monoid[Unit] = new Monoid[Unit] {
    override val empty = ()
  }
  
  implicit def Function1Monoid[A, B](implicit mb: Monoid[B]): Monoid[Function1[A, B]] = 
    new Monoid[Function1[A, B]]()(Semigroup.Function1Semigroup[A, B](mb.semigroup)) {
      override val empty = (x: A) => mb.empty
    }           
  
  implicit lazy val IntPlusMonoid: Monoid[Int] = new Monoid[Int]()(Semigroup.IntPlusSemigroup) {
    override val empty = 0
  }
  
  implicit lazy val IntMultiplyMonoid: Monoid[Int] = new Monoid[Int]()(Semigroup.IntMultiplySemigroup) {
    override val empty = 1
  }
  
  implicit lazy val StringMonoid: Monoid[String] = new Monoid[String] {
    override val empty = ""
  }
  
  implicit def OptionMonoid[A]: Monoid[Option[A]] = new Monoid[Option[A]] {
    override val empty = None
  }
  
  implicit def ListMonoid[A]: Monoid[List[A]] = new Monoid[List[A]] {
    override val empty = Nil
  }
  
  implicit def StreamMonoid[A]: Monoid[Stream[A]] = new Monoid[Stream[A]] {
    override val empty = Stream.empty
  }
  
  implicit def ArrayMonoid[A]: Monoid[Array[A]] = new Monoid[Array[A]] {
    override val empty = new Array[A](0)
  }
}
