// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 7688 $
// $LastChangedDate: 2008-01-25 12:21:26 +1000 (Fri, 25 Jan 2008) $


package scalaz.function

/**
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 7688 $<br>
 *          $LastChangedDate: 2008-01-25 12:21:26 +1000 (Fri, 25 Jan 2008) $<br>
 *          $LastChangedBy: mtony $
 */
final class Function1[-T1, R](f: scala.Function1[T1, R]) {
  def function = f
  
  def apply(v1: T1) = f(v1)

  override def toString = f.toString
  
  def o[A](g: A => T1) = f compose g
  
  def >>[A](g: R => A): T1 => A = f andThen g
}

object Function1 {
  def apply[T1, R](f: scala.Function1[T1, R]) = new Function1(f)

  implicit def ScalaFunction1_Function1[T1, R](f: scala.Function1[T1, R]) = new Function1(f)

  implicit def Function1_ScalaFunction1[T1, R](f: Function1[T1, R]) = f.function
}
