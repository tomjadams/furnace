// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 8078 $
// $LastChangedDate: 2008-02-14 17:03:01 +1000 (Thu, 14 Feb 2008) $


package scalaz.control

import lazytuple.LT2

/**
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 8078 $<br>
 *          $LastChangedDate: 2008-02-14 17:03:01 +1000 (Thu, 14 Feb 2008) $<br>
 *          $LastChangedBy: mtony $
 */
abstract class MonadPlus[M[_]](implicit m: MonadZero[M]) {
  def plus[A](a1: => M[A], a2: => M[A]): M[A]
  def map[A, B](ft: => M[A], f: => A => B) = m.map(ft, f)
  def bind[A, B](ma: => M[A], f: A => M[B]) = m.bind(ma, f)
  def unit[A](a: => A) = m.unit(a)
  def zero[A]: M[A] = m.zero
  lazy val monadZero = m
}

import MonadZero._

object MonadPlus {
  implicit lazy val OptionMonadPlus: MonadPlus[Option] = new MonadPlus[Option] {
    override def plus[A](a1: => Option[A], a2: => Option[A]) = a1 match {
      case None => a2
      case _ => a1 
    }
  }
  implicit lazy val ListMonadPlus: MonadPlus[List] = new MonadPlus[List] {
    override def plus[A](a1: => List[A], a2: => List[A]) = a1 ::: a2
  }
  
  implicit lazy val StreamMonadPlus: MonadPlus[Stream] = new MonadPlus[Stream] {
    override def plus[A](a1: => Stream[A], a2: => Stream[A]) = a1 append a2
  }
  
  implicit lazy val ArrayMonadPlus: MonadPlus[Array] = new MonadPlus[Array] {
    override def plus[A](a1: => Array[A], a2: => Array[A]) = a1 ++ a2
  }
  
  final class MP[M[_], A](ma: => M[A])(implicit mp: MonadPlus[M]) {
    def <+>(mb: => M[A]) = mp.plus(ma, mb)
    def <+:(a: => A) = mp.plus(mp.unit(a), ma)
  }

  implicit def OptionMP[A](as: => Option[A])(implicit m: MonadPlus[Option]): MP[Option, A] = new MP[Option, A](as)(m)
  
  implicit def ListMP[A](as: => List[A])(implicit m: MonadPlus[List]): MP[List, A] = new MP[List, A](as)(m)
  
  implicit def StreamMP[A](as: => Stream[A])(implicit m: MonadPlus[Stream]): MP[Stream, A] = new MP[Stream, A](as)(m)
  
  implicit def ArrayMP[A](as: => Array[A])(implicit m: MonadPlus[Array]): MP[Array, A] = new MP[Array, A](as)(m)
  
  def unfold[A, B, M[_]](f: B => Option[LT2[A, B]], b: B)(implicit m: MonadPlus[M]): M[A] = 
    f(b) match {
      case None => m.zero
      case Some(LT2(a, b)) => m.plus(m.unit(a()), unfold[A, B, M](f, b()))
    }
  
  def replicate[A, M[_]](n: Int, a: A)(implicit m: MonadPlus[M]): M[A] =
    if(n <= 0) m.zero
    else a <+: new MP[M, A](replicate[A, M](n - 1, a))
  
  def plusUnit[A, M[_]](a: A, ma: M[A])(implicit m: MonadPlus[M]): M[A] = 
    m.plus(m.unit(a), ma)    
}
