// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 7944 $
// $LastChangedDate: 2008-02-11 14:25:01 +1000 (Mon, 11 Feb 2008) $


package scalaz.validation;

import java.lang.Byte.parseByte
import Either.throws

/**
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 7944 $<br>
 *          $LastChangedDate: 2008-02-11 14:25:01 +1000 (Mon, 11 Feb 2008) $<br>
 *          $LastChangedBy: mtony $
 */
object Parse {
  def parseBoolean(s: String) = throws(java.lang.Boolean.parseBoolean(s))
  def parseByte(s: String) = throws(java.lang.Byte.parseByte(s))
  def parseDouble(s: String) = throws(java.lang.Double.parseDouble(s))
  def parseFloat(s: String) = throws(java.lang.Float.parseFloat(s))
  def parseInt(s: String) = throws(java.lang.Integer.parseInt(s))
  def parseLong(s: String) = throws(java.lang.Long.parseLong(s))
  def parseShort(s: String) = throws(java.lang.Short.parseShort(s))
}
