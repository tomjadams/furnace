// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 8257 $
// $LastChangedDate: 2008-02-28 11:12:23 +1000 (Thu, 28 Feb 2008) $


package scalaz.list;

/**
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 8257 $<br>
 *          $LastChangedDate: 2008-02-28 11:12:23 +1000 (Thu, 28 Feb 2008) $<br>
 *          $LastChangedBy: mtony $
 */
sealed trait NonEmptyList[+A] {
  val head: A
  val tail: List[A]  
  def <::[B >: A](b: B): NonEmptyList[B]
  def <:::[B >: A](bs: List[B]): NonEmptyList[B]
  def map[B](f: A => B): NonEmptyList[B]
  def flatMap[B](f: A => NonEmptyList[B]): NonEmptyList[B]
  val toList: List[A]
  val toStream: Stream[A]
}
private final case class NEL[+A](a: A, as: List[A]) extends NonEmptyList[A] {
  override val head = a
  override val tail = as
  override def <::[B >: A](b: B) = NEL(b, toList)
  override def <:::[B >: A](bs: List[B]): NonEmptyList[B] = bs match {
    case Nil => this
    case b :: bs => NEL(b, bs ::: a :: as)
  }
  override def map[B](f: A => B): NonEmptyList[B] = NEL(f(a), as.map(f))
  
  override def flatMap[B](f: A => NonEmptyList[B]) = {
    val p = f(a)
    NEL(p.head, p.tail ::: as.flatMap(f(_).toList))    
  }
  override val toList = a :: as
  override val toStream = Stream.cons(a, as.projection)
  override def toString = "NonEmpty" + (a :: as).toString
}

import control.{Semigroup, Functor, Monad}

object NonEmptyList {
  def unapply[A](xs: NonEmptyList[A]): Option[(A, List[A])] = Some(xs.head, xs.tail)
  def apply[A](x: A, xs: A*): NonEmptyList[A] = NEL(x, xs.toList)
  def apply[A](x: A, xs: List[A]): NonEmptyList[A] = NEL(x, xs)
  implicit def toList[A](xs: NonEmptyList[A]): List[A] = xs.toList
  implicit def oToList[A](xs: Option[NonEmptyList[A]]): List[A] = xs match {
    case None => Nil
    case Some(xs) => xs.toList
  }
  implicit def toStream[A](xs: NonEmptyList[A]): Stream[A] = xs.toStream
  
  implicit def NonEmptyListString[A](xs: NonEmptyList[Char]): String = scala.List.toString(xs.toList)
  
  implicit def NonEmptyListOptionList[A](as: List[A]): Option[NonEmptyList[A]] = as match {
    case Nil => None
    case a :: as => Some(NEL(a, as))
  }

  def nel[A](a: A): NonEmptyList[A] = NEL(a, Nil)
  
  implicit def Functor: Functor[NonEmptyList] = new Functor[NonEmptyList] {
    override def map[A, B](ft: => NonEmptyList[A], f: A => B) = ft.map(f)   	 
    override def each[A](ft: => NonEmptyList[A], f: A => Unit) = toList(ft).foreach(f)   	 
  }
  
  def fromList[A](as: List[A], a: => A): NonEmptyList[A] = as match {
    case Nil => NEL(a, Nil)
    case a :: as => NEL(a, as)
  }
  
  def fromList[A](as: List[A]): NonEmptyList[A] = fromList(as, error("fromList with empty List"))
  
  implicit def Monad: Monad[NonEmptyList] = new Monad[NonEmptyList] {
    override def bind[A, B](ma: => NonEmptyList[A], f: A => NonEmptyList[B]) = ma.flatMap(f)
    override def unit[A](a: => A) = nel(a)
  }
  
  implicit def Semigroup[A]: Semigroup[NonEmptyList[A]] = new Semigroup[NonEmptyList[A]] {
    override def append(a1: => NonEmptyList[A], a2: => NonEmptyList[A]): NonEmptyList[A] =
      a1.toList <::: a2      
  }
  
  def flatten[A](as: NonEmptyList[NonEmptyList[A]]) = as.flatMap(x => x)
}
