// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 8117 $
// $LastChangedDate: 2008-02-18 12:25:17 +1000 (Mon, 18 Feb 2008) $


package scalaz.javas;

/**
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 8117 $<br>
 *          $LastChangedDate: 2008-02-18 12:25:17 +1000 (Mon, 18 Feb 2008) $<br>
 *          $LastChangedBy: build $
 */
object Iterator {
  implicit def JavaIterator_Stream[A](i: java.util.Iterator[A]): Stream[A] = {
    if(i.hasNext) {
      val x = i.next
      Stream.cons(x, i)
    } else Stream.empty
  }
}
