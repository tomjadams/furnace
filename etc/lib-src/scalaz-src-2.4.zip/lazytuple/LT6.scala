// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 7688 $
// $LastChangedDate: 2008-01-25 12:21:26 +1000 (Fri, 25 Jan 2008) $


package scalaz.lazytuple;

/**
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 7688 $<br>
 *          $LastChangedDate: 2008-01-25 12:21:26 +1000 (Fri, 25 Jan 2008) $<br>
 *          $LastChangedBy: mtony $
 */
final case class LT6[+A, +B, +C, +D, +E, +F]
  (a: () => A, b: () => B, c: () => C, d: () => D, e: () => E, f: () => F) {
    
  def this(a: A, b: B, c: C, d: D, e: E, f: F) = 
    this(() => a, () => b, () => c, () => d, () => e, () => f)

  lazy val _1 = a()
  lazy val _2 = b()
  lazy val _3 = c()
  lazy val _4 = d()
  lazy val _5 = e()
  lazy val _6 = f()
}

object _LT6 {  
  def unapply[A, B, C, D, E, F](t: LT6[A, B, C, D, E, F]): Option[(A, B, C, D, E, F)] = 
    Some(t._1, t._2, t._3, t._4, t._5, t._6)

  implicit def toTuple[A, B, C, D, E, F](t: => LT6[A, B, C, D, E, F]) = 
    (t._1, t._2, t._3, t._4, t._5, t._6)
}
