// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 7727 $
// $LastChangedDate: 2008-01-29 10:50:40 +1000 (Tue, 29 Jan 2008) $


package scalaz.javas;

/**
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 7727 $<br>
 *          $LastChangedDate: 2008-01-29 10:50:40 +1000 (Tue, 29 Jan 2008) $<br>
 *          $LastChangedBy: mtony $
 */
object Reader {
  implicit def Reader_CharStream(r: java.io.Reader): Stream[Char] = {
    val c = r.read
    if(c == -1) Stream.empty
    else Stream.cons(c.toChar, r)
  }
}
