// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 8011 $
// $LastChangedDate: 2008-02-13 13:18:38 +1000 (Wed, 13 Feb 2008) $


package scalaz.javas;

/**
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 8011 $<br>
 *          $LastChangedDate: 2008-02-13 13:18:38 +1000 (Wed, 13 Feb 2008) $<br>
 *          $LastChangedBy: mtony $
 */
object InputStream {
  implicit def InputStreamByteStream(in: java.io.InputStream): Stream[Byte] = {
    val c = in.read
    if(c == -1) Stream.empty
    else Stream.cons(c.toByte, in)
  }
  
  implicit def InputStreamByteIterator(in: java.io.InputStream) = 
    new Iterator[Byte] {
      var i = in.read
      
      override def next =
        if(i == -1)
          error("Iterator.next (no more elements)")
        else {
          val r = i
          i = in.read
          r.toByte
        }
     
      override def hasNext = i != -1
  }
}
