// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 8377 $
// $LastChangedDate: 2008-03-11 10:21:43 +1000 (Tue, 11 Mar 2008) $


package scalaz.function

/**
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 8377 $<br>
 *          $LastChangedDate: 2008-03-11 10:21:43 +1000 (Tue, 11 Mar 2008) $<br>
 *          $LastChangedBy: mtony $
 */
object Function {
  def const[A, B](a: => A)(b: B) = a

  def uncurry[A, B, C](f: A => B => C) = (a: A, b: B) => f(a)(b)
}
