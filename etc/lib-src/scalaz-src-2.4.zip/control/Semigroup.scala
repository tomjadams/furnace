// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 8386 $
// $LastChangedDate: 2008-03-12 12:54:55 +1000 (Wed, 12 Mar 2008) $


package scalaz.control;

/**
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 8386 $<br>
 *          $LastChangedDate: 2008-03-12 12:54:55 +1000 (Wed, 12 Mar 2008) $<br>
 *          $LastChangedBy: mtony $
 */
trait Semigroup[A] {
  def append(a1: => A, a2: => A): A
}

object Semigroup {
  implicit lazy val UnitSemigroup = new Semigroup[Unit] {
    override def append(a1: => Unit, a2: => Unit) = () 
  }
  
  implicit def Function1Semigroup[A, B](implicit sb: Semigroup[B]) = new Semigroup[Function1[A, B]] {
    override def append(f: => Function1[A, B], g: => Function1[A, B]) = x => sb.append(f(x), g(x))
  }
  
  implicit lazy val IntPlusSemigroup: Semigroup[Int] = new Semigroup[Int] {
    override def append(a1: => Int, a2: => Int) = a1 + a2
  }
  
  implicit lazy val IntMultiplySemigroup: Semigroup[Int] = new Semigroup[Int] {
    override def append(a1: => Int, a2: => Int) = a1 * a2
  }
  
  implicit lazy val StringSemigroup: Semigroup[String] = new Semigroup[String] {
    override def append(a1: => String, a2: => String) = a1 + a2
  }
  
  implicit def OptionSemigroup[A]: Semigroup[Option[A]] = new Semigroup[Option[A]] {
    override def append(a1: => Option[A], a2: => Option[A]) = if(a1.isDefined) a1 else a2
  }
  
  implicit def ListSemigroup[A]: Semigroup[List[A]] = new Semigroup[List[A]] {
    override def append(a1: => List[A], a2: => List[A]) = a1 ::: a2
  }
  
  implicit def StreamSemigroup[A]: Semigroup[Stream[A]] = new Semigroup[Stream[A]] {
    override def append(a1: => Stream[A], a2: => Stream[A]) = a1 append a2
  }
  
  implicit def ArraySemigroup[A]: Semigroup[Array[A]] = new Semigroup[Array[A]] {
    override def append(a1: => Array[A], a2: => Array[A]) = a1 ++ a2
  }
 
  final class SG[A](a1: A)(implicit s: Semigroup[A]) {
    def |+|(a2: A) = s.append(a1, a2)
  }

  implicit def UnitSG(a: => Unit)(implicit s: Semigroup[Unit]): SG[Unit] = new SG[Unit](a)(s)
  
  implicit def Function1SG[A, B](a: => Function1[A, B])(implicit s: Semigroup[Function1[A, B]]): SG[Function1[A, B]] = new SG[Function1[A, B]](a)(s)
  
  implicit def IntSG(a: => Int)(implicit s: Semigroup[Int]): SG[Int] = new SG[Int](a)(s)
  
  implicit def StringSG(a: => String)(implicit s: Semigroup[String]): SG[String] = new SG[String](a)(s)
  
  implicit def OptionSG[A](a: => Option[A])(implicit s: Semigroup[Option[A]]): SG[Option[A]] = new SG[Option[A]](a)(s)
  
  implicit def ListSG[A](a: => List[A])(implicit s: Semigroup[List[A]]): SG[List[A]] = new SG[List[A]](a)(s)
  
  implicit def StreamSG[A](a: => Stream[A])(implicit s: Semigroup[Stream[A]]): SG[Stream[A]] = new SG[Stream[A]](a)(s)
  
  implicit def ArraySG[A](a: => Array[A])(implicit s: Semigroup[Array[A]]): SG[Array[A]] = new SG[Array[A]](a)(s)
}
