// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 8377 $
// $LastChangedDate: 2008-03-11 10:21:43 +1000 (Tue, 11 Mar 2008) $


package scalaz.control

/**
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 8377 $<br>
 *          $LastChangedDate: 2008-03-11 10:21:43 +1000 (Tue, 11 Mar 2008) $<br>
 *          $LastChangedBy: mtony $
 */
abstract class Monad[M[_]](implicit ftr: Functor[M]) {
  def bind[A, B](ma: => M[A], f: A => M[B]): M[B]
  def unit[A](a: => A): M[A]
  def map[A, B](ft: => M[A], f: => A => B) = ftr.map(ft, f)
  lazy val functor = ftr
}

import MonadPlus.plusUnit

object Monad {
  implicit lazy val OptionMonad: Monad[Option] = new Monad[Option] {
    override def bind[A, B](ma: => Option[A], f: A => Option[B]) = ma.flatMap(f)
    override def unit[A](a: => A) = Some(a)
  }

  implicit lazy val ListMonad: Monad[List] = new Monad[List] {
    override def bind[A, B](ma: => List[A], f: A => List[B]) = ma.flatMap(f)
    override def unit[A](a: => A) = a :: Nil
  }

  implicit lazy val StreamMonad: Monad[Stream] = new Monad[Stream] {
    override def bind[A, B](ma: => Stream[A], f: A => Stream[B]) = ma.flatMap(f)
    override def unit[A](a: => A) = Stream.cons(a, Stream.empty)
  }

  implicit lazy val ArrayMonad: Monad[Array] = new Monad[Array] {
    override def bind[A, B](ma: => Array[A], f: A => Array[B]) = ma.flatMap(f)
    override def unit[A](a: => A) = {
      val x = new Array[A](1)
      x(0) = a
      x
    }
  }
  
  final class Mnd[M[_], A](ma: => M[A])(implicit mnd: Monad[M]) {
    def >>=[B](f: A => M[B]) = mnd.bind(ma, f)
    def >>[B](mb: => M[B]) = mnd.bind(ma, (x: A) => mb)
    def =<<:[B](f: A => M[B]) = >>=(f)
    def <<:[B](mb: => M[B]) = >>(mb)
    def ap[B](mf: => M[A => B]) = mnd.bind(ma, (a: A) => mnd.bind(mf, (f: A => B) => mnd.unit(f(a))))
    def apply[B](mf: => M[A => B]) = ap(mf)
    def |:[B](mf: => M[A => B]) = ap(mf)
    def ||>[B, C](mb: => M[B], f: => (A, B) => C) =
      new Mnd[M, B](mb) ap mnd.map[A, B => C](ma, a => b => f(a, b))
    def |||>[B, C, D](mb: => M[B], mc: => M[C], f: => (A, B, C) => D) =
      new Mnd[M, C](mc) ap ||>[B, C => D](mb, (a, b) => c => f(a, b, c))
    def ||||>[B, C, D, E](mb: => M[B], mc: => M[C], md: => M[D], f: => (A, B, C, D) => E) =      
      new Mnd[M, D](md) ap |||>[B, C, D => E](mb, mc, (a, b, c) => d => f(a, b, c, d)) 
    def |||||>[B, C, D, E, F](mb: => M[B], mc: => M[C], md: => M[D], me: => M[E], f: => (A, B, C, D, E) => F) =      
      new Mnd[M, E](me) ap ||||>[B, C, D, E => F](mb, mc, md, (a, b, c, d) => e => f(a, b, c, d, e))     
    def flatMap2[B, C](bs: M[B], f: (A, B) => C) =
      ||> (bs, f)
    def flatMap3[B, C, D](bs: M[B], cs: M[C], f: (A, B, C) => D) =
      |||> (bs, cs, f)
    def flatMap4[B, C, D, E](bs: M[B], cs: M[C], ds: M[D], f: (A, B, C, D) => E) =
      ||||> (bs, cs, ds, f)
    def flatMap5[B, C, D, E, F](bs: M[B], cs: M[C], ds: M[D], es: M[E], f: (A, B, C, D, E) => F) =
      |||||> (bs, cs, ds, es, f)
    def replicate[T[_]](n: Int)(implicit m: MonadPlus[T], f: Foldable[T]): M[T[A]] =
      sequence[A, M, T, T](MonadPlus.replicate[M[A], T](n, ma))         
    def replicateList(n: Int): M[List[A]] =
      replicate[List](n)      
    def mapM[B, MP[_], M2[_]](f: A => M2[B])(implicit m: Monad[M2], fd: Foldable[M], mp: MonadPlus[MP]): M2[MP[B]] =
      sequence[B, M2, M, MP](mnd.map[A, M2[B]](ma, f))
    def mapMList[B, M2[_]](f: A => M2[B])(implicit m: Monad[M2], fd: Foldable[M]): M2[List[B]] =
      mapM[B, List, M2](f)
  }
  
  implicit def OptionMnd[A](as: => Option[A])(implicit m: Monad[Option]): Mnd[Option, A] = new Mnd[Option, A](as)(m)
  
  implicit def ListMnd[A](as: => List[A])(implicit m: Monad[List]): Mnd[List, A] = new Mnd[List, A](as)(m)
   
  implicit def StreamMnd[A](as: => Stream[A])(implicit m: Monad[Stream]): Mnd[Stream, A] = new Mnd[Stream, A](as)(m)
   
  implicit def ArrayMnd[A](as: => Array[A])(implicit m: Monad[Array]): Mnd[Array, A] = new Mnd[Array, A](as)(m)
   
  def join[M[_], A](ma: M[M[A]])(implicit m: Monad[M]): M[A] = m.bind(ma, identity[M[A]])
  
  def sum[F[_], M[_], A](as: F[M[A]])(implicit f: Foldable[F], m: MonadPlus[M]) =
    f.foldRight[M[A], M[A]](as, m.zero, m.plus(_, _))
    
  def filterM[A, M[_], F[_]](f: A => M[Boolean], as: F[A])(implicit m: Monad[M], fd: Foldable[F], mp: MonadPlus[F]): M[F[A]] =
    fd.foldRight[A, M[F[A]]](as, m.unit(mp.zero), (a, b) => m.bind(f(a), (c: Boolean) => 
      m.bind(b, (ys: F[A]) => m.unit(if(c) MonadPlus.plusUnit[A, F](a, ys) else ys))))
    
  def foldM[A, B, M[_], F[_]](f: (B, A) => M[A], a: A, bs: F[B])(implicit m: Monad[M], fd: Foldable[F]): M[A] =
    fd.foldRight[B, M[A]](bs, m.unit(a), (a, b) => m.bind[A, A](b, f(a, _)))
    
  def guard[M[_]](c: Boolean)(implicit m: MonadPlus[M]): M[Unit] =
    if(c) m.unit(()) else m.zero
  
  def when[M[_]](c: Boolean, s: M[Unit])(implicit m: MonadPlus[M]): M[Unit] = 
    if(c) s else m.unit(())
  
  def unless[M[_]](c: Boolean, s: M[Unit])(implicit m: MonadPlus[M]): M[Unit] = 
    if(c) m.unit(()) else s
  
  def sequence[A, M[_], FD[_], MP[_]](ms: FD[M[A]])(implicit m: Monad[M], fd: Foldable[FD], mp: MonadPlus[MP]): M[MP[A]] =
    fd.foldRight[M[A], M[MP[A]]](ms, m.unit(mp.zero), (a, b) =>  m.bind(a, (x: A) => m.bind(b, (xs: MP[A]) => m.unit(plusUnit[A, MP](x, xs)))))
}
