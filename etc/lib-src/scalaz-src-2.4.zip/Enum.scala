// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 7688 $
// $LastChangedDate: 2008-01-25 12:21:26 +1000 (Fri, 25 Jan 2008) $


package scalaz

// todo allow optimisation
/**
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 7688 $<br>
 *          $LastChangedDate: 2008-01-25 12:21:26 +1000 (Fri, 25 Jan 2008) $<br>
 *          $LastChangedBy: mtony $
 */
trait Enum[A] {
  def apply(a: A) = successor(a)
  
  def successor(a: A): Option[A]

  def predecessor(a: A): Option[A]
}

object Enum {
  implicit def EnumBoolean = new Enum[Boolean] {
    override def successor(a: Boolean) = a match {
      case true => None
      case _ => Some(true)
    }

    override def predecessor(a: Boolean) = a match {
      case false => None
      case _ => Some(false)
    }
  }

  implicit def EnumByte = new Enum[Byte] {
    override def successor(a: Byte) = a match {
      case java.lang.Byte.MAX_VALUE => None
      case _ => Some((a + 1).toByte)
    }

    override def predecessor(a: Byte) = a match {
      case Integer.MIN_VALUE => None
      case _ => Some((a - 1).toByte)
    }
  }

  implicit def EnumChar = new Enum[Char] {
    override def successor(a: Char) = a match {
      case Character.MAX_VALUE => None
      case _ => Some((a.toInt + 1).toChar)
    }

    override def predecessor(a: Char) = a match {
      case Character.MIN_VALUE => None
      case _ => Some((a.toInt - 1).toChar)
    }
  }

  implicit def EnumDouble = new Enum[Double] {
    override def successor(a: Double) = a match {
      case java.lang.Double.MAX_VALUE => None
      case _ => Some(a + 1.0)
    }

    override def predecessor(a: Double) = a match {
      case java.lang.Double.MIN_VALUE => None
      case _ => Some(a - 1.0)
    }
  }

  implicit def EnumFloat = new Enum[Float] {
    override def successor(a: Float) = a match {
      case java.lang.Float.MAX_VALUE => None
      case _ => Some(a + 1.0F)
    }

    override def predecessor(a: Float) = a match {
      case java.lang.Float.MIN_VALUE => None
      case _ => Some(a - 1.0F)
    }
  }

  implicit def EnumInt = new Enum[Int] {
    override def successor(a: Int) = a match {
      case Integer.MAX_VALUE => None
      case _ => Some(a + 1)
    }

    override def predecessor(a: Int) = a match {
      case Integer.MIN_VALUE => None
      case _ => Some(a - 1)
    }
  }

  implicit def EnumLong = new Enum[Long] {
    override def successor(a: Long) = a match {
      case java.lang.Long.MAX_VALUE => None
      case _ => Some(a + 1L)
    }

    override def predecessor(a: Long) = a match {
      case java.lang.Long.MIN_VALUE => None
      case _ => Some(a - 1L)
    }
  }

  implicit def EnumShort = new Enum[Short] {
    override def successor(a: Short) = a match {
      case java.lang.Short.MAX_VALUE => None
      case _ => Some((a.toInt + 1).toShort)
    }

    override def predecessor(a: Short) = a match {
      case java.lang.Short.MIN_VALUE => None
      case _ => Some((a.toInt - 1).toShort)
    }
  }   
}
