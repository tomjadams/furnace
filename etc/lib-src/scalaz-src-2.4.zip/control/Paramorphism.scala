// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 7688 $
// $LastChangedDate: 2008-01-25 12:21:26 +1000 (Fri, 25 Jan 2008) $


package scalaz.control;

/**
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 7688 $<br>
 *          $LastChangedDate: 2008-01-25 12:21:26 +1000 (Fri, 25 Jan 2008) $<br>
 *          $LastChangedBy: mtony $
 */
trait Paramorphism[T[_], U[_]] {
  def para[A, B](f: ((=> A, => U[A], B) => B), b: B, as: T[A]): B
}

import MonadPlus.plusUnit

object Paramorphism {
  implicit lazy val OptionOptionParamorphism = new Paramorphism[Option, Option] {
    override def para[A, B](f: ((=> A, => Option[A], B) => B), b: B, as: Option[A]): B = as match {
      case None => b
      case Some(a) => f(a, None, b)
    }
  }
  
  implicit lazy val ListListParamorphism = new Paramorphism[List, List] {
    override def para[A, B](f: ((=> A, => List[A], B) => B), b: B, as: List[A]): B = as match {
      case Nil => b
      case a :: as => f(a, as, para(f, b, as))
    }
  }
  
  implicit lazy val StreamStreamParamorphism = new Paramorphism[Stream, Stream] {
    override def para[A, B](f: ((=> A, => Stream[A], B) => B), b: B, as: Stream[A]): B = 
      if(as.isEmpty) b
      else f(as.head, as.tail, para(f, b, as.tail))
  }
  
  final class Para[T[_], U[_], A](as: => T[A])(implicit pr: Paramorphism[T, U]) {
    def para[B](f: ((=> A, => U[A], B) => B), b: B): B =
      pr.para[A, B](f, b, as)
    
    def *|*(f: A => Boolean)(implicit m: MonadPlus[U]) =
      pr.para[A, (U[A], U[A])]((x, xs, asbs) => if(f(x)) (plusUnit[A, U](x, asbs._1), asbs._2) else (m.zero, plusUnit[A, U](x, xs)), (m.zero: U[A], m.zero: U[A]), as)
    
    def ~|~(f: A => Boolean)(implicit m: MonadPlus[U]) = 
      *|*(!f(_))
  }
  
  implicit def OptionOptionPara[A](as: => Option[A])(implicit p: Paramorphism[Option, Option]): Para[Option, Option, A] = 
    new Para[Option, Option, A](as)(p)
  
  implicit def ListListPara[A](as: => List[A])(implicit p: Paramorphism[List, List]): Para[List, List, A] = 
    new Para[List, List, A](as)(p)
  
  implicit def StreamStreamPara[A](as: => Stream[A])(implicit p: Paramorphism[Stream, Stream]): Para[Stream, Stream, A] = 
    new Para[Stream, Stream, A](as)(p)  

  def FoldableMonadPlusParamorphism[T[_], U[_]](implicit fd: Foldable[T], m: MonadPlus[U]) = new Paramorphism[T, U] {
    override def para[A, B](f: ((=> A, => U[A], B) => B), b: B, as: T[A]): B = {
      fd.foldRight[A, (U[A], B)](as, (m.zero, b), (a, asb) =>
        (plusUnit[A, U](a, asb._1), f(a, asb._1, asb._2)))._2
    }
  }
  
  def dropWhile[A, T[_]](f: A => Boolean, as: T[A])(implicit p: Paramorphism[T, T], m: MonadPlus[T]) =
    p.para[A, T[A]]((x, xs, ys) => if(f(x)) ys else plusUnit[A, T](x, xs), m.zero, as)
}
