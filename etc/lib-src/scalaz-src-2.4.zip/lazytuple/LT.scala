// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 7688 $
// $LastChangedDate: 2008-01-25 12:21:26 +1000 (Fri, 25 Jan 2008) $


package scalaz.lazytuple;

/**
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 7688 $<br>
 *          $LastChangedDate: 2008-01-25 12:21:26 +1000 (Fri, 25 Jan 2008) $<br>
 *          $LastChangedBy: mtony $
 */
object LT {
  def apply[A, B](a: => A, b: => B) = LT2(() => a, () => b)
  def apply[A, B, C](a: => A, b: => B, c: => C) = LT3(() => a, () => b, () => c)
  def apply[A, B, C, D](a: => A, b: => B, c: => C, d: => D) =
    LT4(() => a, () => b, () => c, () => d)
  def apply[A, B, C, D, E](a: => A, b: => B, c: => C, d: => D, e: => E) = 
    LT5(() => a, () => b, () => c, () => d, () => e)
  def apply[A, B, C, D, E, F](a: => A, b: => B, c: => C, d: => D, e: => E, f: => F) = 
    LT6(() => a, () => b, () => c, () => d, () => e, () => f)
  def apply[A, B, C, D, E, F, G](a: => A, b: => B, c: => C, d: => D, e: => E, f: => F, g: => G) = 
    LT7(() => a, () => b, () => c, () => d, () => e, () => f, () => g)
  
}
