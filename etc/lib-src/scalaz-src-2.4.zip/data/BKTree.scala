// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 7771 $
// $LastChangedDate: 2008-01-31 18:31:12 +1000 (Thu, 31 Jan 2008) $


package scalaz.data;

/**
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 7771 $<br>
 *          $LastChangedDate: 2008-01-31 18:31:12 +1000 (Thu, 31 Jan 2008) $<br>
 *          $LastChangedBy: mtony $
 */
sealed trait BKTree[+A] {
  def isEmpty = this match {
    case Nil => true
    case _ => false
  }
  
  def ++[AA >: A](a: AA)(implicit m: Metric[AA]): BKTree[AA] = this match {
    case Nil => Node(a, Map.empty)
    case Node(b, map) => {
      val d = m.distance(a, b)
      
      Node(b, map + ((d, (map.get(d) match {
        case None => Node(a, Map.empty)
        case Some(tree) => tree ++ a
      }))))
    }
  }
  
  def contains[AA >: A](a: AA)(implicit m: Metric[AA]): Boolean = this match {
    case Nil => false
    case Node(b, map) => {
      val d = m.distance(a, b)
      d == 0 || (map.get(d) match {
        case None => false
        case Some(tree) => tree.contains(a)
      })
    }
  }
}
private final case object Nil extends BKTree[Nothing]
private final case class Node[A](a: A, m: Map[Int, BKTree[A]]) extends BKTree[A]

object BKTree {
  def empty[A]: BKTree[A] = Nil
  
  def singleton[A](a: A): BKTree[A] = Node(a, Map.empty)
}
