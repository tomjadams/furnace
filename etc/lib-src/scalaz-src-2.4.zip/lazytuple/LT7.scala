// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 7688 $
// $LastChangedDate: 2008-01-25 12:21:26 +1000 (Fri, 25 Jan 2008) $


package scalaz.lazytuple;

/**
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 7688 $<br>
 *          $LastChangedDate: 2008-01-25 12:21:26 +1000 (Fri, 25 Jan 2008) $<br>
 *          $LastChangedBy: mtony $
 */
final case class LT7[+A, +B, +C, +D, +E, +F, +G]
  (a: () => A, b: () => B, c: () => C, d: () => D, e: () => E, f: () => F, g: () => G) {
  
  def this(a: A, b: B, c: C, d: D, e: E, f: F, g: G) = 
    this(() => a, () => b, () => c, () => d, () => e, () => f, () => g)
  
  lazy val _1 = a()
  lazy val _2 = b()
  lazy val _3 = c()
  lazy val _4 = d()
  lazy val _5 = e()
  lazy val _6 = f()
  lazy val _7 = g()
}

object _LT7 {
  def unapply[A, B, C, D, E, F, G](t: LT7[A, B, C, D, E, F, G]): Option[(A, B, C, D, E, F, G)] = 
    Some(t._1, t._2, t._3, t._4, t._5, t._6, t._7)

  implicit def toTuple[A, B, C, D, E, F, G](t: => LT7[A, B, C, D, E, F, G]) = 
    (t._1, t._2, t._3, t._4, t._5, t._6, t._7)
}
