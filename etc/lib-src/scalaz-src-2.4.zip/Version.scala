// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 7912 $
// $LastChangedDate: 2008-02-11 08:51:51 +1000 (Mon, 11 Feb 2008) $


package scalaz;

/**
 * Prints the version of this software.
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision<br>
 *          $LastChangedDate<br>
 *          $LastChangedBy: mtony $
 */
object Version extends Application {
  println("Scalaz version 2.5")
  println("Compiled against Scala version 2.7.0")
  println("Tested using ScalaCheck version 1.2")
  println("Copyright 2008 Workingmouse Pty. Ltd.")
}
