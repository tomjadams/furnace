// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 8078 $
// $LastChangedDate: 2008-02-14 17:03:01 +1000 (Thu, 14 Feb 2008) $


package scalaz.control

/**
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 8078 $<br>
 *          $LastChangedDate: 2008-02-14 17:03:01 +1000 (Thu, 14 Feb 2008) $<br>
 *          $LastChangedBy: mtony $
 */
abstract class MonadOr[M[_]](implicit m: MonadZero[M]) {
  def orelse[A](a1: => M[A], a2: => M[A]): M[A]
  def map[A, B](ft: => M[A], f: => A => B) = m.map(ft, f)
  def bind[A, B](ma: => M[A], f: A => M[B]) = m.bind(ma, f)
  def unit[A](a: => A) = m.unit(a)
  def zero[A]: M[A] = m.zero
  lazy val monadZero = m
}

object MonadOr {
  implicit lazy val OptionMonadOr: MonadOr[Option] = new MonadOr[Option] {
    override def orelse[A](a1: => Option[A], a2: => Option[A]) = if(a1.isEmpty) a2 else a1
  }  
  
  implicit lazy val ListMonadOr: MonadOr[List] = new MonadOr[List] {
    override def orelse[A](a1: => List[A], a2: => List[A]) = if(a1.isEmpty) a2 else a1
  }
  
  implicit lazy val StreamMonadOr: MonadOr[Stream] = new MonadOr[Stream] {
    override def orelse[A](a1: => Stream[A], a2: => Stream[A]) = if(a1.isEmpty) a2 else a1
  }
  
  implicit lazy val ArrayMonadOr: MonadOr[Array] = new MonadOr[Array] {
    override def orelse[A](a1: => Array[A], a2: => Array[A]) = if(a1.isEmpty) a2 else a1
  }
  
  final class MO[M[_], A](ma: => M[A])(implicit mo: MonadOr[M]) {
    def |:|(mb: => M[A]) = mo.orelse(ma, mb)
  }
  
  implicit def OptionMO[A](as: => Option[A])(implicit m: MonadOr[Option]): MO[Option, A] = new MO[Option, A](as)(m)
  
  implicit def ListMO[A](as: => List[A])(implicit m: MonadOr[List]): MO[List, A] = new MO[List, A](as)(m)
  
  implicit def StreamMO[A](as: => Stream[A])(implicit m: MonadOr[Stream]): MO[Stream, A] = new MO[Stream, A](as)(m)
  
  implicit def ArrayMO[A](as: => Array[A])(implicit m: MonadOr[Array]): MO[Array, A] = new MO[Array, A](as)(m)  
}
