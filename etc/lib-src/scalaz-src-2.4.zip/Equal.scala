// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 8046 $
// $LastChangedDate: 2008-02-13 16:27:03 +1000 (Wed, 13 Feb 2008) $


package scalaz

/**
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 8046 $<br>
 *          $LastChangedDate: 2008-02-13 16:27:03 +1000 (Wed, 13 Feb 2008) $<br>
 *          $LastChangedBy: mtony $
 */
trait Equal[A] {
  def apply(a1: A, a2: A): Boolean = eq(a1, a2)
  def eq(a1: A, a2: A): Boolean = !neq(a1, a2)
  def neq(a1: A, a2: A): Boolean = !eq(a1, a2)
}

object Equal {
  def equal[A](a1: A, a2: A)(implicit e: Equal[A]) =
    e.eq(a1, a2)
  
  def notEqual[A](a1: A, a2: A)(implicit e: Equal[A]) =
    e.neq(a1, a2)
      
  def EqualA[A] = new Equal[A] {
    override def eq(a1: A, a2: A) = a1 == a2
  }
  
  implicit def EqualBoolean = EqualA[Boolean]
  implicit def EqualByte = EqualA[Byte]
  implicit def EqualChar = EqualA[Char]
  implicit def EqualDouble = EqualA[Double]
  implicit def EqualFloat = EqualA[Float]
  implicit def EqualInt = EqualA[Int]
  implicit def EqualLong = EqualA[Long]
  implicit def EqualShort = EqualA[Short]
  implicit def EqualUnit = EqualA[Unit]
  implicit def EqualString = EqualA[String]

  import Stream.cons
  
  implicit def EqualStream[A](implicit e: Equal[A]) = new Equal[Stream[A]] {
    override def eq(a1: Stream[A], a2: Stream[A]) = 
      if(a1.isEmpty) a2.isEmpty
      else !a2.isEmpty && e.eq(a1.head, a2.head) && eq(a1.tail, a2.tail)
  }

  implicit def EqualList[A](implicit e: Equal[A]) = new Equal[List[A]] {
    override def eq(a1: List[A], a2: List[A]) = (a1, a2) match {
      case (x :: xs, y :: ys) => e.eq(x, y) && eq(xs, ys)
      case (Nil, Nil) => true
      case _ => false
    }
  }

  implicit def EqualArray[A](implicit e: Equal[A]) = new Equal[Array[A]] {
    override def eq(a1: Array[A], a2: Array[A]) =
      a1.length == a2.length && a1.zip(a2).forall { case (a, b) => e.eq(a, b) }
  }
  
  implicit def EqualOption[A](implicit e: Equal[A]) = new Equal[Option[A]] {
    override def eq(a1: Option[A], a2: Option[A]) = (a1, a2) match {
      case (Some(x), Some(y)) => e.eq(x, y)
      case (None, None) => true
      case _ => false
    }      
  }
  
  // Thanks David MacIver
  
  import scala.collection.immutable.Map

  /**
   * Note that value equality of immutable maps is defined purely in terms
   * of value equality of the *Values*. Keys use their normal equality test.
   * This is necessary due to the semantics of Map. 
   */
  implicit def EqualImmutableMap[K, V](implicit e: Equal[V]): Equal[Map[K, V]] = new Equal[Map[K, V]]{
    override def eq(x: Map[K, V], y: Map[K, V]) =
      x.size == y.size &&
      x.forall { case (k, v) => y.get(k).exists(e(v, _)) }     
  }

// Generated instances for tuples.
  implicit def EqualTuple2[T1, T2](implicit 
      eq1 : Equal[T1],
      eq2 : Equal[T2]) =
    new Equal[Tuple2[T1, T2]] {
      override def eq(x : Tuple2[T1, T2], y : Tuple2[T1, T2]) = 
        eq1(x._1, y._1)&&
        eq2(x._2, y._2);
    }

  implicit def EqualTuple3[T1, T2, T3](implicit 
      eq1 : Equal[T1],
      eq2 : Equal[T2],
      eq3 : Equal[T3]) =
    new Equal[Tuple3[T1, T2, T3]] {
      override def eq(x : Tuple3[T1, T2, T3], y : Tuple3[T1, T2, T3]) = 
        eq1(x._1, y._1)&&
        eq2(x._2, y._2)&&
        eq3(x._3, y._3);
    }

  implicit def EqualTuple4[T1, T2, T3, T4](implicit 
      eq1 : Equal[T1],
      eq2 : Equal[T2],
      eq3 : Equal[T3],
      eq4 : Equal[T4]) =
    new Equal[Tuple4[T1, T2, T3, T4]] {
      override def eq(x : Tuple4[T1, T2, T3, T4], y : Tuple4[T1, T2, T3, T4]) = 
        eq1(x._1, y._1)&&
        eq2(x._2, y._2)&&
        eq3(x._3, y._3)&&
        eq4(x._4, y._4);
    }

  implicit def EqualTuple5[T1, T2, T3, T4, T5](implicit 
      eq1 : Equal[T1],
      eq2 : Equal[T2],
      eq3 : Equal[T3],
      eq4 : Equal[T4],
      eq5 : Equal[T5]) =
    new Equal[Tuple5[T1, T2, T3, T4, T5]] {
      override def eq(x : Tuple5[T1, T2, T3, T4, T5], y : Tuple5[T1, T2, T3, T4, T5]) = 
        eq1(x._1, y._1)&&
        eq2(x._2, y._2)&&
        eq3(x._3, y._3)&&
        eq4(x._4, y._4)&&
        eq5(x._5, y._5);
    }

  implicit def EqualTuple6[T1, T2, T3, T4, T5, T6](implicit 
      eq1 : Equal[T1],
      eq2 : Equal[T2],
      eq3 : Equal[T3],
      eq4 : Equal[T4],
      eq5 : Equal[T5],
      eq6 : Equal[T6]) =
    new Equal[Tuple6[T1, T2, T3, T4, T5, T6]] {
      override def eq(x : Tuple6[T1, T2, T3, T4, T5, T6], y : Tuple6[T1, T2, T3, T4, T5, T6]) = 
        eq1(x._1, y._1)&&
        eq2(x._2, y._2)&&
        eq3(x._3, y._3)&&
        eq4(x._4, y._4)&&
        eq5(x._5, y._5)&&
        eq6(x._6, y._6);
    }

  implicit def EqualTuple7[T1, T2, T3, T4, T5, T6, T7](implicit 
      eq1 : Equal[T1],
      eq2 : Equal[T2],
      eq3 : Equal[T3],
      eq4 : Equal[T4],
      eq5 : Equal[T5],
      eq6 : Equal[T6],
      eq7 : Equal[T7]) =
    new Equal[Tuple7[T1, T2, T3, T4, T5, T6, T7]] {
      override def eq(x : Tuple7[T1, T2, T3, T4, T5, T6, T7], y : Tuple7[T1, T2, T3, T4, T5, T6, T7]) = 
        eq1(x._1, y._1)&&
        eq2(x._2, y._2)&&
        eq3(x._3, y._3)&&
        eq4(x._4, y._4)&&
        eq5(x._5, y._5)&&
        eq6(x._6, y._6)&&
        eq7(x._7, y._7);
    }

  implicit def EqualTuple8[T1, T2, T3, T4, T5, T6, T7, T8](implicit 
      eq1 : Equal[T1],
      eq2 : Equal[T2],
      eq3 : Equal[T3],
      eq4 : Equal[T4],
      eq5 : Equal[T5],
      eq6 : Equal[T6],
      eq7 : Equal[T7],
      eq8 : Equal[T8]) =
    new Equal[Tuple8[T1, T2, T3, T4, T5, T6, T7, T8]] {
      override def eq(x : Tuple8[T1, T2, T3, T4, T5, T6, T7, T8], y : Tuple8[T1, T2, T3, T4, T5, T6, T7, T8]) = 
        eq1(x._1, y._1)&&
        eq2(x._2, y._2)&&
        eq3(x._3, y._3)&&
        eq4(x._4, y._4)&&
        eq5(x._5, y._5)&&
        eq6(x._6, y._6)&&
        eq7(x._7, y._7)&&
        eq8(x._8, y._8);
    }

  implicit def EqualTuple9[T1, T2, T3, T4, T5, T6, T7, T8, T9](implicit 
      eq1 : Equal[T1],
      eq2 : Equal[T2],
      eq3 : Equal[T3],
      eq4 : Equal[T4],
      eq5 : Equal[T5],
      eq6 : Equal[T6],
      eq7 : Equal[T7],
      eq8 : Equal[T8],
      eq9 : Equal[T9]) =
    new Equal[Tuple9[T1, T2, T3, T4, T5, T6, T7, T8, T9]] {
      override def eq(x : Tuple9[T1, T2, T3, T4, T5, T6, T7, T8, T9], y : Tuple9[T1, T2, T3, T4, T5, T6, T7, T8, T9]) = 
        eq1(x._1, y._1)&&
        eq2(x._2, y._2)&&
        eq3(x._3, y._3)&&
        eq4(x._4, y._4)&&
        eq5(x._5, y._5)&&
        eq6(x._6, y._6)&&
        eq7(x._7, y._7)&&
        eq8(x._8, y._8)&&
        eq9(x._9, y._9);
    }

  implicit def EqualTuple10[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10](implicit 
      eq1 : Equal[T1],
      eq2 : Equal[T2],
      eq3 : Equal[T3],
      eq4 : Equal[T4],
      eq5 : Equal[T5],
      eq6 : Equal[T6],
      eq7 : Equal[T7],
      eq8 : Equal[T8],
      eq9 : Equal[T9],
      eq10 : Equal[T10]) =
    new Equal[Tuple10[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10]] {
      override def eq(x : Tuple10[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10], y : Tuple10[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10]) = 
        eq1(x._1, y._1)&&
        eq2(x._2, y._2)&&
        eq3(x._3, y._3)&&
        eq4(x._4, y._4)&&
        eq5(x._5, y._5)&&
        eq6(x._6, y._6)&&
        eq7(x._7, y._7)&&
        eq8(x._8, y._8)&&
        eq9(x._9, y._9)&&
        eq10(x._10, y._10);
    }

  implicit def EqualTuple11[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11](implicit 
      eq1 : Equal[T1],
      eq2 : Equal[T2],
      eq3 : Equal[T3],
      eq4 : Equal[T4],
      eq5 : Equal[T5],
      eq6 : Equal[T6],
      eq7 : Equal[T7],
      eq8 : Equal[T8],
      eq9 : Equal[T9],
      eq10 : Equal[T10],
      eq11 : Equal[T11]) =
    new Equal[Tuple11[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11]] {
      override def eq(x : Tuple11[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11], y : Tuple11[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11]) = 
        eq1(x._1, y._1)&&
        eq2(x._2, y._2)&&
        eq3(x._3, y._3)&&
        eq4(x._4, y._4)&&
        eq5(x._5, y._5)&&
        eq6(x._6, y._6)&&
        eq7(x._7, y._7)&&
        eq8(x._8, y._8)&&
        eq9(x._9, y._9)&&
        eq10(x._10, y._10)&&
        eq11(x._11, y._11);
    }

  implicit def EqualTuple12[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12](implicit 
      eq1 : Equal[T1],
      eq2 : Equal[T2],
      eq3 : Equal[T3],
      eq4 : Equal[T4],
      eq5 : Equal[T5],
      eq6 : Equal[T6],
      eq7 : Equal[T7],
      eq8 : Equal[T8],
      eq9 : Equal[T9],
      eq10 : Equal[T10],
      eq11 : Equal[T11],
      eq12 : Equal[T12]) =
    new Equal[Tuple12[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12]] {
      override def eq(x : Tuple12[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12], y : Tuple12[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12]) = 
        eq1(x._1, y._1)&&
        eq2(x._2, y._2)&&
        eq3(x._3, y._3)&&
        eq4(x._4, y._4)&&
        eq5(x._5, y._5)&&
        eq6(x._6, y._6)&&
        eq7(x._7, y._7)&&
        eq8(x._8, y._8)&&
        eq9(x._9, y._9)&&
        eq10(x._10, y._10)&&
        eq11(x._11, y._11)&&
        eq12(x._12, y._12);
    }

  implicit def EqualTuple13[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13](implicit 
      eq1 : Equal[T1],
      eq2 : Equal[T2],
      eq3 : Equal[T3],
      eq4 : Equal[T4],
      eq5 : Equal[T5],
      eq6 : Equal[T6],
      eq7 : Equal[T7],
      eq8 : Equal[T8],
      eq9 : Equal[T9],
      eq10 : Equal[T10],
      eq11 : Equal[T11],
      eq12 : Equal[T12],
      eq13 : Equal[T13]) =
    new Equal[Tuple13[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13]] {
      override def eq(x : Tuple13[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13], y : Tuple13[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13]) = 
        eq1(x._1, y._1)&&
        eq2(x._2, y._2)&&
        eq3(x._3, y._3)&&
        eq4(x._4, y._4)&&
        eq5(x._5, y._5)&&
        eq6(x._6, y._6)&&
        eq7(x._7, y._7)&&
        eq8(x._8, y._8)&&
        eq9(x._9, y._9)&&
        eq10(x._10, y._10)&&
        eq11(x._11, y._11)&&
        eq12(x._12, y._12)&&
        eq13(x._13, y._13);
    }

  implicit def EqualTuple14[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14](implicit 
      eq1 : Equal[T1],
      eq2 : Equal[T2],
      eq3 : Equal[T3],
      eq4 : Equal[T4],
      eq5 : Equal[T5],
      eq6 : Equal[T6],
      eq7 : Equal[T7],
      eq8 : Equal[T8],
      eq9 : Equal[T9],
      eq10 : Equal[T10],
      eq11 : Equal[T11],
      eq12 : Equal[T12],
      eq13 : Equal[T13],
      eq14 : Equal[T14]) =
    new Equal[Tuple14[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14]] {
      override def eq(x : Tuple14[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14], y : Tuple14[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14]) = 
        eq1(x._1, y._1)&&
        eq2(x._2, y._2)&&
        eq3(x._3, y._3)&&
        eq4(x._4, y._4)&&
        eq5(x._5, y._5)&&
        eq6(x._6, y._6)&&
        eq7(x._7, y._7)&&
        eq8(x._8, y._8)&&
        eq9(x._9, y._9)&&
        eq10(x._10, y._10)&&
        eq11(x._11, y._11)&&
        eq12(x._12, y._12)&&
        eq13(x._13, y._13)&&
        eq14(x._14, y._14);
    }

  implicit def EqualTuple15[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15](implicit 
      eq1 : Equal[T1],
      eq2 : Equal[T2],
      eq3 : Equal[T3],
      eq4 : Equal[T4],
      eq5 : Equal[T5],
      eq6 : Equal[T6],
      eq7 : Equal[T7],
      eq8 : Equal[T8],
      eq9 : Equal[T9],
      eq10 : Equal[T10],
      eq11 : Equal[T11],
      eq12 : Equal[T12],
      eq13 : Equal[T13],
      eq14 : Equal[T14],
      eq15 : Equal[T15]) =
    new Equal[Tuple15[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15]] {
      override def eq(x : Tuple15[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15], y : Tuple15[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15]) = 
        eq1(x._1, y._1)&&
        eq2(x._2, y._2)&&
        eq3(x._3, y._3)&&
        eq4(x._4, y._4)&&
        eq5(x._5, y._5)&&
        eq6(x._6, y._6)&&
        eq7(x._7, y._7)&&
        eq8(x._8, y._8)&&
        eq9(x._9, y._9)&&
        eq10(x._10, y._10)&&
        eq11(x._11, y._11)&&
        eq12(x._12, y._12)&&
        eq13(x._13, y._13)&&
        eq14(x._14, y._14)&&
        eq15(x._15, y._15);
    }

  implicit def EqualTuple16[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16](implicit 
      eq1 : Equal[T1],
      eq2 : Equal[T2],
      eq3 : Equal[T3],
      eq4 : Equal[T4],
      eq5 : Equal[T5],
      eq6 : Equal[T6],
      eq7 : Equal[T7],
      eq8 : Equal[T8],
      eq9 : Equal[T9],
      eq10 : Equal[T10],
      eq11 : Equal[T11],
      eq12 : Equal[T12],
      eq13 : Equal[T13],
      eq14 : Equal[T14],
      eq15 : Equal[T15],
      eq16 : Equal[T16]) =
    new Equal[Tuple16[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16]] {
      override def eq(x : Tuple16[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16], y : Tuple16[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16]) = 
        eq1(x._1, y._1)&&
        eq2(x._2, y._2)&&
        eq3(x._3, y._3)&&
        eq4(x._4, y._4)&&
        eq5(x._5, y._5)&&
        eq6(x._6, y._6)&&
        eq7(x._7, y._7)&&
        eq8(x._8, y._8)&&
        eq9(x._9, y._9)&&
        eq10(x._10, y._10)&&
        eq11(x._11, y._11)&&
        eq12(x._12, y._12)&&
        eq13(x._13, y._13)&&
        eq14(x._14, y._14)&&
        eq15(x._15, y._15)&&
        eq16(x._16, y._16);
    }

  implicit def EqualTuple17[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17](implicit 
      eq1 : Equal[T1],
      eq2 : Equal[T2],
      eq3 : Equal[T3],
      eq4 : Equal[T4],
      eq5 : Equal[T5],
      eq6 : Equal[T6],
      eq7 : Equal[T7],
      eq8 : Equal[T8],
      eq9 : Equal[T9],
      eq10 : Equal[T10],
      eq11 : Equal[T11],
      eq12 : Equal[T12],
      eq13 : Equal[T13],
      eq14 : Equal[T14],
      eq15 : Equal[T15],
      eq16 : Equal[T16],
      eq17 : Equal[T17]) =
    new Equal[Tuple17[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17]] {
      override def eq(x : Tuple17[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17], y : Tuple17[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17]) = 
        eq1(x._1, y._1)&&
        eq2(x._2, y._2)&&
        eq3(x._3, y._3)&&
        eq4(x._4, y._4)&&
        eq5(x._5, y._5)&&
        eq6(x._6, y._6)&&
        eq7(x._7, y._7)&&
        eq8(x._8, y._8)&&
        eq9(x._9, y._9)&&
        eq10(x._10, y._10)&&
        eq11(x._11, y._11)&&
        eq12(x._12, y._12)&&
        eq13(x._13, y._13)&&
        eq14(x._14, y._14)&&
        eq15(x._15, y._15)&&
        eq16(x._16, y._16)&&
        eq17(x._17, y._17);
    }

  implicit def EqualTuple18[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18](implicit 
      eq1 : Equal[T1],
      eq2 : Equal[T2],
      eq3 : Equal[T3],
      eq4 : Equal[T4],
      eq5 : Equal[T5],
      eq6 : Equal[T6],
      eq7 : Equal[T7],
      eq8 : Equal[T8],
      eq9 : Equal[T9],
      eq10 : Equal[T10],
      eq11 : Equal[T11],
      eq12 : Equal[T12],
      eq13 : Equal[T13],
      eq14 : Equal[T14],
      eq15 : Equal[T15],
      eq16 : Equal[T16],
      eq17 : Equal[T17],
      eq18 : Equal[T18]) =
    new Equal[Tuple18[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18]] {
      override def eq(x : Tuple18[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18], y : Tuple18[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18]) = 
        eq1(x._1, y._1)&&
        eq2(x._2, y._2)&&
        eq3(x._3, y._3)&&
        eq4(x._4, y._4)&&
        eq5(x._5, y._5)&&
        eq6(x._6, y._6)&&
        eq7(x._7, y._7)&&
        eq8(x._8, y._8)&&
        eq9(x._9, y._9)&&
        eq10(x._10, y._10)&&
        eq11(x._11, y._11)&&
        eq12(x._12, y._12)&&
        eq13(x._13, y._13)&&
        eq14(x._14, y._14)&&
        eq15(x._15, y._15)&&
        eq16(x._16, y._16)&&
        eq17(x._17, y._17)&&
        eq18(x._18, y._18);
    }

  implicit def EqualTuple19[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19](implicit 
      eq1 : Equal[T1],
      eq2 : Equal[T2],
      eq3 : Equal[T3],
      eq4 : Equal[T4],
      eq5 : Equal[T5],
      eq6 : Equal[T6],
      eq7 : Equal[T7],
      eq8 : Equal[T8],
      eq9 : Equal[T9],
      eq10 : Equal[T10],
      eq11 : Equal[T11],
      eq12 : Equal[T12],
      eq13 : Equal[T13],
      eq14 : Equal[T14],
      eq15 : Equal[T15],
      eq16 : Equal[T16],
      eq17 : Equal[T17],
      eq18 : Equal[T18],
      eq19 : Equal[T19]) =
    new Equal[Tuple19[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19]] {
      override def eq(x : Tuple19[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19], y : Tuple19[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19]) = 
        eq1(x._1, y._1)&&
        eq2(x._2, y._2)&&
        eq3(x._3, y._3)&&
        eq4(x._4, y._4)&&
        eq5(x._5, y._5)&&
        eq6(x._6, y._6)&&
        eq7(x._7, y._7)&&
        eq8(x._8, y._8)&&
        eq9(x._9, y._9)&&
        eq10(x._10, y._10)&&
        eq11(x._11, y._11)&&
        eq12(x._12, y._12)&&
        eq13(x._13, y._13)&&
        eq14(x._14, y._14)&&
        eq15(x._15, y._15)&&
        eq16(x._16, y._16)&&
        eq17(x._17, y._17)&&
        eq18(x._18, y._18)&&
        eq19(x._19, y._19);
    }

  implicit def EqualTuple20[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20](implicit 
      eq1 : Equal[T1],
      eq2 : Equal[T2],
      eq3 : Equal[T3],
      eq4 : Equal[T4],
      eq5 : Equal[T5],
      eq6 : Equal[T6],
      eq7 : Equal[T7],
      eq8 : Equal[T8],
      eq9 : Equal[T9],
      eq10 : Equal[T10],
      eq11 : Equal[T11],
      eq12 : Equal[T12],
      eq13 : Equal[T13],
      eq14 : Equal[T14],
      eq15 : Equal[T15],
      eq16 : Equal[T16],
      eq17 : Equal[T17],
      eq18 : Equal[T18],
      eq19 : Equal[T19],
      eq20 : Equal[T20]) =
    new Equal[Tuple20[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20]] {
      override def eq(x : Tuple20[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20], y : Tuple20[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20]) = 
        eq1(x._1, y._1)&&
        eq2(x._2, y._2)&&
        eq3(x._3, y._3)&&
        eq4(x._4, y._4)&&
        eq5(x._5, y._5)&&
        eq6(x._6, y._6)&&
        eq7(x._7, y._7)&&
        eq8(x._8, y._8)&&
        eq9(x._9, y._9)&&
        eq10(x._10, y._10)&&
        eq11(x._11, y._11)&&
        eq12(x._12, y._12)&&
        eq13(x._13, y._13)&&
        eq14(x._14, y._14)&&
        eq15(x._15, y._15)&&
        eq16(x._16, y._16)&&
        eq17(x._17, y._17)&&
        eq18(x._18, y._18)&&
        eq19(x._19, y._19)&&
        eq20(x._20, y._20);
    }

  implicit def EqualTuple21[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21](implicit 
      eq1 : Equal[T1],
      eq2 : Equal[T2],
      eq3 : Equal[T3],
      eq4 : Equal[T4],
      eq5 : Equal[T5],
      eq6 : Equal[T6],
      eq7 : Equal[T7],
      eq8 : Equal[T8],
      eq9 : Equal[T9],
      eq10 : Equal[T10],
      eq11 : Equal[T11],
      eq12 : Equal[T12],
      eq13 : Equal[T13],
      eq14 : Equal[T14],
      eq15 : Equal[T15],
      eq16 : Equal[T16],
      eq17 : Equal[T17],
      eq18 : Equal[T18],
      eq19 : Equal[T19],
      eq20 : Equal[T20],
      eq21 : Equal[T21]) =
    new Equal[Tuple21[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21]] {
      override def eq(x : Tuple21[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21], y : Tuple21[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21]) = 
        eq1(x._1, y._1)&&
        eq2(x._2, y._2)&&
        eq3(x._3, y._3)&&
        eq4(x._4, y._4)&&
        eq5(x._5, y._5)&&
        eq6(x._6, y._6)&&
        eq7(x._7, y._7)&&
        eq8(x._8, y._8)&&
        eq9(x._9, y._9)&&
        eq10(x._10, y._10)&&
        eq11(x._11, y._11)&&
        eq12(x._12, y._12)&&
        eq13(x._13, y._13)&&
        eq14(x._14, y._14)&&
        eq15(x._15, y._15)&&
        eq16(x._16, y._16)&&
        eq17(x._17, y._17)&&
        eq18(x._18, y._18)&&
        eq19(x._19, y._19)&&
        eq20(x._20, y._20)&&
        eq21(x._21, y._21);
    }

  implicit def EqualTuple22[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22](implicit 
      eq1 : Equal[T1],
      eq2 : Equal[T2],
      eq3 : Equal[T3],
      eq4 : Equal[T4],
      eq5 : Equal[T5],
      eq6 : Equal[T6],
      eq7 : Equal[T7],
      eq8 : Equal[T8],
      eq9 : Equal[T9],
      eq10 : Equal[T10],
      eq11 : Equal[T11],
      eq12 : Equal[T12],
      eq13 : Equal[T13],
      eq14 : Equal[T14],
      eq15 : Equal[T15],
      eq16 : Equal[T16],
      eq17 : Equal[T17],
      eq18 : Equal[T18],
      eq19 : Equal[T19],
      eq20 : Equal[T20],
      eq21 : Equal[T21],
      eq22 : Equal[T22]) =
    new Equal[Tuple22[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22]] {
      override def eq(x : Tuple22[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22], y : Tuple22[T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16, T17, T18, T19, T20, T21, T22]) = 
        eq1(x._1, y._1)&&
        eq2(x._2, y._2)&&
        eq3(x._3, y._3)&&
        eq4(x._4, y._4)&&
        eq5(x._5, y._5)&&
        eq6(x._6, y._6)&&
        eq7(x._7, y._7)&&
        eq8(x._8, y._8)&&
        eq9(x._9, y._9)&&
        eq10(x._10, y._10)&&
        eq11(x._11, y._11)&&
        eq12(x._12, y._12)&&
        eq13(x._13, y._13)&&
        eq14(x._14, y._14)&&
        eq15(x._15, y._15)&&
        eq16(x._16, y._16)&&
        eq17(x._17, y._17)&&
        eq18(x._18, y._18)&&
        eq19(x._19, y._19)&&
        eq20(x._20, y._20)&&
        eq21(x._21, y._21)&&
        eq22(x._22, y._22);
    }
}
