// Copyright Workingmouse Pty. Ltd. 2007, 2008
// This software is released under an open source BSD licence.

// $LastChangedRevision: 8328 $
// $LastChangedDate: 2008-03-05 13:24:17 +1000 (Wed, 05 Mar 2008) $


package scalaz;

/**
 *
 * @author <a href="mailto:research@workingmouse.com">Tony Morris</a>
 * @version $LastChangedRevision: 8328 $<br>
 *          $LastChangedDate: 2008-03-05 13:24:17 +1000 (Wed, 05 Mar 2008) $<br>
 *          $LastChangedBy: mtony $
 */
final class LList[A](as: List[A]) {
  import LList._
   
	def list = as
  
  def list[X](nil: => X, cons: (A, List[A]) => X) = as match {
    case Nil => nil
    case a :: as => cons(a, as)
  }
  
  def breaks(f: A => Boolean) = 
    as.foldRight[List[List[A]]](Nil :: Nil)((a, as) => {
      lazy val x = f(a) == (!as.head.isEmpty && f(as.head.head))
      (a :: (if(x) as.head else Nil)) :: (if(as.isEmpty) Nil else if(x) as.tail else as)       
    }) 
  
  def splitEvery(n: Int): List[List[A]] =
    as.splitAt(n) match {
      case (as, Nil) => as :: Nil
      case (as, bs) => as :: bs.splitEvery(n)
    }
  
  def =|=(aas: List[A]) =
    as.length == aas.length && as.forall(a => aas.filter(_ == a) == as.filter(_ == a))
   
  def ?[X](nil: => X, cons: => X) = as match {
    case Nil => nil
    case _ :: _ => cons
  }
  
  import scala.List.flatten
  import control.Foldable.ListF
  
  def insert(n: Int, a: A): List[A] =
    flatten((as splitEvery n).intersperse[List]((a :: Nil) :: Nil))
    
  def insertEvery(n: Int, a: A, breakWhen: A => Boolean): List[A] = 
    flatten(as.breaks(breakWhen).map(t => if(t.exists(!breakWhen(_))) t.insert(n, a) else t))
        
  def scanLeft[B](b: B)(f: (B, A) => B): List[B] = b :: (as match {
    case Nil => Nil
    case x :: xs => xs.scanLeft(f(b, x))(f)   
  })
    
  def scanRight[B](b: B)(f: (A, B) => B): List[B] = as match {
    case Nil => b :: Nil
    case x :: xs => {
      lazy val t = xs.scanRight(b)(f)
      f(x, t.head) :: t
    }
  }
  
  def scanLeft1(f: (A, A) => A) = as match {
    case Nil => Nil
    case x :: xs => xs.scanLeft(x)(f)
  }
  
  def scanRight1(f: (A, A) => A): List[A] = as match {
    case Nil => Nil
    case x :: Nil => x :: Nil
    case x :: xs => {
      val t = xs.scanRight1(f)
      f(x, t.head) :: t
    }
  }    
  
  lazy val tails: List[List[A]] = as match {
    case Nil => Nil :: Nil
    case (xxs @ _ :: xs) => xxs :: xs.tails
  }
  
  lazy val inits: List[List[A]] = as match {
    case Nil => Nil :: Nil
    case x :: xs => Nil :: Nil ::: (xs.inits.map(x :: _))
  }
  
  import Function.untupled
  
  def zip3[B, C](bs: List[B], cs: List[C]) = 
    zipWith3[B, C, (A, B, C)](untupled(x => x), bs, cs)
  
  def zip4[B, C, D](bs: List[B], cs: List[C], ds: List[D]) = 
    zipWith4[B, C, D, (A, B, C, D)](untupled(x => x), bs, cs, ds)
  
  def zip5[B, C, D, E](bs: List[B], cs: List[C], ds: List[D], es: List[E]) = 
    zipWith5[B, C, D, E, (A, B, C, D, E)](untupled(x => x), bs, cs, ds, es)
  
  def zip6[B, C, D, E, F](bs: List[B], cs: List[C], ds: List[D], es: List[E], fs: List[F]) = 
    zipWith6[B, C, D, E, F, (A, B, C, D, E, F)]((a, b, c, d, e, f) => (a, b, c, d, e, f), bs, cs, ds, es, fs)
  
  def zip7[B, C, D, E, F, G](bs: List[B], cs: List[C], ds: List[D], es: List[E], fs: List[F], gs: List[G]) = 
    zipWith7[B, C, D, E, F, G, (A, B, C, D, E, F, G)]((a, b, c, d, e, f, g) => (a, b, c, d, e, f, g), bs, cs, ds, es, fs, gs)
  
  def zipWith[B, C](f: (A, B) => C, bs: List[B]): List[C] = (as, bs) match {    
    case (a :: as, b :: bs) => f(a, b) :: as.zipWith(f, bs)
    case (_, _) => Nil
  }
  
  def zipWith3[B, C, D](f: (A, B, C) => D, bs: List[B], cs: List[C]): List[D] = (as, bs, cs) match {    
    case (a :: as, b :: bs, c :: cs) => f(a, b, c) :: as.zipWith3(f, bs, cs)
    case (_, _, _) => Nil
  }
  
  def zipWith4[B, C, D, E](f: (A, B, C, D) => E, bs: List[B], cs: List[C], ds: List[D]): List[E] = (as, bs, cs, ds) match {    
    case (a :: as, b :: bs, c :: cs, d :: ds) => f(a, b, c, d) :: as.zipWith4(f, bs, cs, ds)
    case (_, _, _, _) => Nil
  }
  
  def zipWith5[B, C, D, E, F](f: (A, B, C, D, E) => F, bs: List[B], cs: List[C], ds: List[D], es: List[E]): List[F] = (as, bs, cs, ds, es) match {    
    case (a :: as, b :: bs, c :: cs, d :: ds, e :: es) => f(a, b, c, d, e) :: as.zipWith5(f, bs, cs, ds, es)
    case (_, _, _, _, _) => Nil
  }
  
  def zipWith6[B, C, D, E, F, G](fc: (A, B, C, D, E, F) => G, bs: List[B], cs: List[C], ds: List[D], es: List[E], fs: List[F]): List[G] = (as, bs, cs, ds, es, fs) match {    
    case (a :: as, b :: bs, c :: cs, d :: ds, e :: es, f :: fs) => fc(a, b, c, d, e, f) :: as.zipWith6(fc, bs, cs, ds, es, fs)
    case (_, _, _, _, _, _) => Nil
  }
  
  def zipWith7[B, C, D, E, F, G, H](fc: (A, B, C, D, E, F, G) => H, bs: List[B], cs: List[C], ds: List[D], es: List[E], fs: List[F], gs: List[G]): List[H] = (as, bs, cs, ds, es, fs, gs) match {    
    case (a :: as, b :: bs, c :: cs, d :: ds, e :: es, f :: fs, g :: gs) => fc(a, b, c, d, e, f, g) :: as.zipWith7(fc, bs, cs, ds, es, fs, gs)
    case (_, _, _, _, _, _, _) => Nil
  }
}

object LList {
  implicit def LListList[A](as: LList[A]) = as.list
  
  implicit def ListLList[A](as: List[A]) = new LList(as)
  
  import control.MonadPlus
  import lazytuple.LT2
  
  def unfold[A, B](f: B => Option[LT2[A, B]], b: B) = MonadPlus.unfold[A, B, List](f, b)
  
  def unzip3[A, B, C](xs: List[(A, B, C)]) =
    xs.foldRight((Nil: List[A], Nil: List[B], Nil: List[C]))(
        (abc, x) => (abc._1 :: x._1, abc._2 :: x._2, abc._3 :: x._3))
        
  def unzip4[A, B, C, D](xs: List[(A, B, C, D)]) =
    xs.foldRight((Nil: List[A], Nil: List[B], Nil: List[C], Nil: List[D]))(
        (abcd, x) => (abcd._1 :: x._1, abcd._2 :: x._2, abcd._3 :: x._3, abcd._4 :: x._4))
        
  def unzip5[A, B, C, D, E](xs: List[(A, B, C, D, E)]) =
    xs.foldRight((Nil: List[A], Nil: List[B], Nil: List[C], Nil: List[D], Nil: List[E]))(
        (abcde, x) => (abcde._1 :: x._1, abcde._2 :: x._2, abcde._3 :: x._3, abcde._4 :: x._4, abcde._5 :: x._5))
        
  def unzip6[A, B, C, D, E, F](xs: List[(A, B, C, D, E, F)]) =
    xs.foldRight((Nil: List[A], Nil: List[B], Nil: List[C], Nil: List[D], Nil: List[E], Nil: List[F]))(
        (abcdef, x) => (abcdef._1 :: x._1, abcdef._2 :: x._2, abcdef._3 :: x._3, abcdef._4 :: x._4, abcdef._5 :: x._5, abcdef._6 :: x._6))
        
  def unzip7[A, B, C, D, E, F, G](xs: List[(A, B, C, D, E, F, G)]) =
    xs.foldRight((Nil: List[A], Nil: List[B], Nil: List[C], Nil: List[D], Nil: List[E], Nil: List[F], Nil: List[G]))(
        (abcdefg, x) => (abcdefg._1 :: x._1, abcdefg._2 :: x._2, abcdefg._3 :: x._3, abcdefg._4 :: x._4, abcdefg._5 :: x._5, abcdefg._6 :: x._6, abcdefg._7 :: x._7))
}
